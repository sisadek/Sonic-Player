package com.example.domain.model

data class Song(
    val id: String,
    val title: String,
    val artist: String,
    val album: String,
    val duration: Long,
    val uriStr: String,
    val isFavorite: Boolean = false,
    val lyrics: String? = null,
    val syncedLyrics: List<SyncedLine> = emptyList()
)

data class SyncedLine(
    val timeMs: Long,
    val text: String
)

data class Artist(
    val name: String,
    val trackCount: Int,
    val imageUrl: String? = null
)

data class Album(
    val title: String,
    val artist: String,
    val trackCount: Int,
    val imageUrl: String? = null
)

data class Playlist(
    val id: String,
    val name: String,
    val trackCount: Int = 0
)
