package com.example.visualizer

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.random.Random

class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var radius: Float,
    var alpha: Float,
    val color: Color
) {
    fun update(width: Float, height: Float, speedMultiplier: Float) {
        x += vx * speedMultiplier
        y += vy * speedMultiplier
        
        if (x < 0 || x > width) vx = -vx
        if (y < 0 || y > height) vy = -vy
        
        x = x.coerceIn(0f, width)
        y = y.coerceIn(0f, height)
    }
}

@Composable
fun ParticleVisualizer(
    beatDetected: Boolean,
    bassValue: Float,
    colorPreset: ColorPreset,
    modifier: Modifier = Modifier
) {
    val maxParticles = 60
    val colors = remember(colorPreset) {
        val resolved = ColorPresetResolver.getColors(colorPreset)
        listOf(resolved.first, resolved.second, Color(0xFFFF9800), Color(0xFF00E676))
    }

    val particles = remember {
        ArrayList<Particle>().apply {
            for (i in 0 until maxParticles) {
                add(
                    Particle(
                        x = Random.nextFloat() * 1000f,
                        y = Random.nextFloat() * 1500f,
                        vx = (Random.nextFloat() - 0.5f) * 3f,
                        vy = (Random.nextFloat() - 0.5f) * 3f,
                        radius = Random.nextFloat() * 5f + 2.5f,
                        alpha = Random.nextFloat() * 0.4f + 0.25f,
                        color = colors.random()
                    )
                )
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "Particles")
    val ticker by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particleClock"
    )

    val speedFactor = remember(bassValue, beatDetected, ticker) {
        val baseSpeed = 0.7f
        val boost = (bassValue * 0.7f) + (if (beatDetected) 2.8f else 0f)
        (baseSpeed + boost).coerceIn(0.1f, 6.0f)
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        particles.forEach { p ->
            if (p.x > width || p.y > height || p.x == 0f) {
                p.x = Random.nextFloat() * width
                p.y = Random.nextFloat() * height
            }

            val activeRadius = if (beatDetected) p.radius * 2.0f else p.radius
            val activeAlpha = if (beatDetected) (p.alpha * 1.6f).coerceAtMost(1f) else p.alpha

            drawCircle(
                color = p.color.copy(alpha = activeAlpha),
                radius = activeRadius.dp.toPx(),
                center = Offset(p.x, p.y)
            )

            p.update(width, height, speedFactor)
        }
    }
}

@Composable
fun AmbientGlowVisualizer(
    beatDetected: Boolean,
    bassValue: Float,
    colorPreset: ColorPreset,
    modifier: Modifier = Modifier
) {
    val colors = remember(colorPreset) {
        val resolved = ColorPresetResolver.getColors(colorPreset)
        Pair(resolved.first, resolved.second)
    }

    val transition = rememberInfiniteTransition(label = "ambient")
    val pulse by transition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val baseRadius = Math.min(size.width, size.height) * 0.45f
        val bassTerm = (bassValue * 0.12f).coerceIn(0f, 0.4f)
        val beatTerm = if (beatDetected) 0.3f else 0f
        val radius = baseRadius * (pulse + bassTerm + beatTerm)

        val alpha = (0.25f + bassTerm + beatTerm).coerceAtMost(0.7f)

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(colors.first.copy(alpha = alpha), colors.second.copy(alpha = 0f)),
                center = center,
                radius = radius.coerceAtLeast(10f)
            ),
            radius = radius,
            center = center
        )
    }
}
