package com.example.visualizer

import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max

class FrequencyBandMapper(private val numBands: Int) {
    
    private var binMappings = IntArray(numBands * 2) // [startBin, endBin, ...]
    private var interpolationWeights = FloatArray(numBands)
    private var sampleRate = 44100
    private var fftSize = 1024

    init {
        recalculateBands()
    }

    /**
     * Reconfigures boundaries if sample rate or FFT size changes dynamically.
     */
    fun configure(sampleRate: Int, fftSize: Int) {
        if (this.sampleRate != sampleRate || this.fftSize != fftSize) {
            this.sampleRate = sampleRate
            this.fftSize = fftSize
            recalculateBands()
        }
    }

    private fun recalculateBands() {
        val minFreq = 20.0
        val maxFreq = 22000.0
        val numBins = fftSize / 2
        val binWidth = sampleRate.toDouble() / fftSize

        // Map frequencies logarithmically to matches human perception
        val logMin = ln(minFreq)
        val logMax = ln(maxFreq)
        val step = (logMax - logMin) / numBands

        for (i in 0 until numBands) {
            val fStart = exp(logMin + i * step)
            val fEnd = exp(logMin + (i + 1) * step)

            var binStart = (fStart / binWidth).toInt().coerceIn(0, numBins - 1)
            var binEnd = (fEnd / binWidth).toInt().coerceIn(binStart, numBins - 1)

            binMappings[i * 2] = binStart
            binMappings[i * 2 + 1] = binEnd

            // Linear weight for sub-bin interpolation
            val exactBinStart = fStart / binWidth
            interpolationWeights[i] = (exactBinStart - binStart).toFloat().coerceIn(0f, 1f)
        }
    }

    /**
     * Maps raw linear FFT bin magnitudes to our logarithmic frequency bands.
     * Incorporates:
     * - Sub-bin interpolation for smooth low-end mapping (preventing stepped response)
     * - Multi-band parametric bass enhancement for extreme kick drum and bass drop reaction
     * - Sub-band adjustments for presence, mid, and treble
     */
    fun mapFftToBands(magnitudes: FloatArray, bassStrength: Float = 1.3f): FloatArray {
        val bands = FloatArray(numBands)
        val numBins = magnitudes.size
        if (numBins == 0) return bands

        for (i in 0 until numBands) {
            val binStart = binMappings[i * 2]
            val binEnd = binMappings[i * 2 + 1]

            var sum = 0f
            var totalWeight = 0f

            if (binStart == binEnd) {
                // Low-frequency interpolation between adjacent bins
                val currentVal = magnitudes.getOrElse(binStart) { 0f }
                val nextVal = magnitudes.getOrElse((binStart + 1).coerceAtMost(numBins - 1)) { 0f }
                val t = interpolationWeights[i]
                sum = currentVal * (1.0f - t) + nextVal * t
                totalWeight = 1.0f
            } else {
                for (bin in binStart..binEnd) {
                    val weight = if (bin == binStart) 1.0f - interpolationWeights[i] else 1.0f
                    sum += magnitudes.getOrElse(bin) { 0f } * weight
                    totalWeight += weight
                }
            }

            var value = if (totalWeight > 0f) sum / totalWeight else 0f

            // Equalization Curve Optimization (Enhanced for visual visual punchiness)
            val x = i.toFloat() / numBands
            if (x < 0.15f) {
                // Sub-bass & Bass Boost (Kick & Drops)
                val boostVal = (1.0f - x / 0.15f) * bassStrength * 1.5f
                value *= (1.0f + boostVal)
            } else if (x < 0.35f) {
                // Mid-bass punch
                val boostVal = (1.0f - (x - 0.15f) / 0.20f) * bassStrength * 0.5f
                value *= (1.0f + boostVal)
            } else if (x > 0.70f) {
                // Treble spike enhancement (Vocal presence, high hats, synths)
                val trebleLift = ((x - 0.70f) / 0.30f) * 0.8f
                value *= (1.0f + trebleLift)
            }

            bands[i] = value
        }

        return bands
    }
}
