package com.example.visualizer

class PeakHoldProcessor(private val numBands: Int) {
    
    private val peaks = FloatArray(numBands)
    private val holdCounters = IntArray(numBands)
    private val fallSpeeds = FloatArray(numBands)

    // Configuration for realistic physical movement
    var holdDurationFrames = 20  // Hold peak for ~330ms at 60 FPS
    var gravity = 0.0015f        // Acceleration of peak fall
    var baseDecayRate = 0.01f    // Constant downward speed factor

    /**
     * Updates and returns peak values based on current band values.
     */
    fun update(currentBands: FloatArray): FloatArray {
        for (i in 0 until numBands) {
            val value = currentBands.getOrElse(i) { 0f }

            if (value >= peaks[i]) {
                // Audio spike: Peak instantly rises, holding timer is reset
                peaks[i] = value
                holdCounters[i] = holdDurationFrames
                fallSpeeds[i] = 0f
            } else {
                // Hold & Fall phase
                if (holdCounters[i] > 0) {
                    holdCounters[i]--
                } else {
                    // Accelerate down under gravity
                    fallSpeeds[i] += gravity
                    peaks[i] = (peaks[i] - fallSpeeds[i] - baseDecayRate).coerceAtLeast(0f)
                }
            }

            // Ensure peak never goes below the current value
            if (peaks[i] < value) {
                peaks[i] = value
                fallSpeeds[i] = 0f
            }
        }
        return peaks.clone()
    }

    fun reset() {
        peaks.fill(0f)
        holdCounters.fill(0)
        fallSpeeds.fill(0f)
    }
}
