package com.example.visualizer

import com.example.SonicPlayerApplication
import kotlinx.coroutines.flow.Flow

object VisualizerSettings {
    private val settingsRepository = SonicPlayerApplication.instance.settingsRepository

    val isEnabled: Flow<Boolean> = settingsRepository.visEnabledFlow
    val type: Flow<VisualizerType> = settingsRepository.visTypeFlow
    val sensitivity: Flow<Float> = settingsRepository.visSensitivityFlow
    val fpsLimit: Flow<Int> = settingsRepository.visFpsLimitFlow
    val barWidth: Flow<Float> = settingsRepository.visBarWidthFlow
    val barSpacing: Flow<Float> = settingsRepository.visBarSpacingFlow
    val colorPreset: Flow<ColorPreset> = settingsRepository.visColorPresetFlow
    val useDynamicColors: Flow<Boolean> = settingsRepository.visDynamicColorsFlow
    val quality: Flow<VisualizerQuality> = settingsRepository.visQualityFlow

    suspend fun setEnabled(enabled: Boolean) {
        settingsRepository.setVisEnabled(enabled)
    }

    suspend fun setType(type: VisualizerType) {
        settingsRepository.setVisType(type)
    }

    suspend fun setSensitivity(sensitivity: Float) {
        settingsRepository.setVisSensitivity(sensitivity)
    }

    suspend fun setFpsLimit(fps: Int) {
        settingsRepository.setVisFpsLimit(fps)
    }

    suspend fun setBarWidth(width: Float) {
        settingsRepository.setVisBarWidth(width)
    }

    suspend fun setBarSpacing(spacing: Float) {
        settingsRepository.setVisBarSpacing(spacing)
    }

    suspend fun setColorPreset(preset: ColorPreset) {
        settingsRepository.setVisColorPreset(preset)
    }

    suspend fun setUseDynamicColors(enabled: Boolean) {
        settingsRepository.setVisDynamicColors(enabled)
    }

    suspend fun setQuality(quality: VisualizerQuality) {
        settingsRepository.setVisQuality(quality)
    }
}
