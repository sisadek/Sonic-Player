package com.example.visualizer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

@Composable
fun WaveformVisualizer(
    waveform: FloatArray,
    colorPreset: ColorPreset,
    modifier: Modifier = Modifier
) {
    val colors = remember(colorPreset) {
        val resolved = ColorPresetResolver.getColors(colorPreset)
        listOf(resolved.first, resolved.second)
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val centerY = size.height / 2f
        val maxAmplitude = size.height * 0.4f

        if (waveform.isEmpty()) return@Canvas

        val path = Path()
        val step = width / (waveform.size - 1).coerceAtLeast(1)

        for (i in waveform.indices) {
            val rawVal = waveform[i]
            val x = i * step
            val y = centerY + rawVal * maxAmplitude
            
            if (i == 0) {
                path.moveTo(x, y)
            } else {
                path.lineTo(x, y)
            }
        }

        val gradient = Brush.horizontalGradient(colors)
        
        val filledPath = Path().apply {
            addPath(path)
            lineTo(width, size.height)
            lineTo(0f, size.height)
            close()
        }
        
        drawPath(
            path = filledPath,
            brush = Brush.verticalGradient(
                colors = listOf(colors.first().copy(alpha = 0.15f), Color.Transparent),
                startY = centerY - maxAmplitude,
                endY = size.height
            )
        )

        drawPath(
            path = path,
            brush = gradient,
            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round),
            alpha = 0.4f
        )

        drawPath(
            path = path,
            color = Color.White,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}
