package com.example.visualizer

import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.hypot

object FFTProcessor {

    /**
     * In-place Cooley-Tukey Radix-2 FFT on float arrays representing real and imaginary parts.
     * Highly optimized for real-time high-performance 60 FPS analysis.
     * Length of real and imag arrays must be a power of 2 (e.g., 512, 1024).
     */
    fun fft(real: FloatArray, imag: FloatArray) {
        val n = real.size
        if (n <= 1) return

        // Bit-reversal permutation index swap
        var i = 0
        for (j in 1 until n) {
            var bit = n shr 1
            while (i and bit != 0) {
                i = i xor bit
                bit = bit shr 1
            }
            i = i xor bit
            if (j < i) {
                val tempR = real[j]
                real[j] = real[i]
                real[i] = tempR

                val tempI = imag[j]
                imag[j] = imag[i]
                imag[i] = tempI
            }
        }

        // FFT Butterfly merge stages
        var len = 2
        while (len <= n) {
            val ang = (2.0 * Math.PI / len).toFloat()
            val wpr = cos(ang.toDouble()).toFloat()
            val wpi = -sin(ang.toDouble()).toFloat()
            
            val halfLen = len shr 1
            for (sliceStart in 0 until n step len) {
                var wr = 1.0f
                var wi = 0.0f
                for (j in 0 until halfLen) {
                    val a = sliceStart + j
                    val b = sliceStart + j + halfLen
                    
                    val tr = real[b] * wr - imag[b] * wi
                    val ti = real[b] * wi + imag[b] * wr
                    
                    real[b] = real[a] - tr
                    imag[b] = imag[a] - ti
                    
                    real[a] = real[a] + tr
                    imag[a] = imag[a] + ti
                    
                    val nextWr = wr * wpr - wi * wpi
                    wi = wr * wpi + wi * wpr
                    wr = nextWr
                }
            }
            len = len shl 1
        }
    }

    /**
     * Applies a Hanning window function to input samples to prevent spectral leakage.
     */
    fun applyHannWindow(data: FloatArray) {
        val n = data.size
        for (i in 0 until n) {
            val multiplier = 0.5f * (1.0f - cos((2.0 * Math.PI * i) / (n - 1)).toFloat())
            data[i] *= multiplier
        }
    }

    /**
     * Calculates absolute magnitudes for the positive-frequency spectrum.
     */
    fun calculateMagnitudes(pcmData: FloatArray): FloatArray {
        val n = pcmData.size
        val real = pcmData.clone()
        val imag = FloatArray(n)

        applyHannWindow(real)
        fft(real, imag)

        val half = n / 2
        val magnitudes = FloatArray(half)
        for (k in 0 until half) {
            magnitudes[k] = sqrt(real[k] * real[k] + imag[k] * imag[k])
        }

        return magnitudes
    }

    /**
     * Legacy support function for system Visualizer API data byte arrays.
     */
    fun processFFT(fft: ByteArray): FloatArray {
        if (fft.isEmpty()) return FloatArray(0)
        
        val n = fft.size
        val magnitudes = FloatArray(n / 2)
        
        magnitudes[0] = Math.abs(fft[0].toInt()).toFloat()
        
        for (i in 1 until n / 2) {
            val r = fft[2 * i].toInt()
            val im = fft[2 * i + 1].toInt()
            val mag = hypot(r.toDouble(), im.toDouble()).toFloat()
            magnitudes[i] = mag
        }
        return magnitudes
    }

    /**
     * Legacy support function to compress linear magnitudes to logarithmic bands.
     */
    fun getLogarithmicBands(magnitudes: FloatArray, numBands: Int): FloatArray {
        if (magnitudes.isEmpty()) return FloatArray(numBands)
        val bands = FloatArray(numBands)
        val numBins = magnitudes.size
        
        for (i in 0 until numBands) {
            val lowFreqRatio = i.toFloat() / numBands
            val highFreqRatio = (i + 1).toFloat() / numBands
            
            val startBin = (Math.pow(numBins.toDouble(), lowFreqRatio.toDouble()) - 1).toInt().coerceIn(0, numBins - 1)
            val endBin = (Math.pow(numBins.toDouble(), highFreqRatio.toDouble()) - 1).toInt().coerceIn(startBin, numBins - 1)
            
            var sum = 0f
            var count = 0
            for (bin in startBin..endBin) {
                sum += magnitudes[bin]
                count++
            }
            bands[i] = if (count > 0) sum / count else 0f
        }
        return bands
    }
}
