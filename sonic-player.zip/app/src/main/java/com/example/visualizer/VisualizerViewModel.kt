package com.example.visualizer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.SonicPlayerApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class VisualizerType {
    SPECTRUM_NARROW,
    SPECTRUM_WIDE,
    WAVEFORM,
    CIRCULAR,
    PARTICLE,
    AMBIENT_GLOW
}

enum class VisualizerQuality {
    LOW, MEDIUM, HIGH, ULTRA_HD
}

enum class ColorPreset {
    CYBERPUNK,
    AURORA,
    MONOCHROME,
    FIRE,
    ELECTRIC
}

class VisualizerViewModel : ViewModel() {
    val visualizerManager = AudioVisualizerManager()
    private val settingsRepository = SonicPlayerApplication.instance.settingsRepository

    private val _isEnabled = MutableStateFlow(true)
    val isEnabled = _isEnabled.asStateFlow()

    private val _visualizerType = MutableStateFlow(VisualizerType.SPECTRUM_NARROW)
    val visualizerType = _visualizerType.asStateFlow()

    private val _sensitivity = MutableStateFlow(1.0f)
    val sensitivity = _sensitivity.asStateFlow()

    private val _fpsLimit = MutableStateFlow(60)
    val fpsLimit = _fpsLimit.asStateFlow()

    private val _barWidthDp = MutableStateFlow(4f)
    val barWidthDp = _barWidthDp.asStateFlow()

    private val _barSpacingDp = MutableStateFlow(2f)
    val barSpacingDp = _barSpacingDp.asStateFlow()

    private val _colorPreset = MutableStateFlow(ColorPreset.CYBERPUNK)
    val colorPreset = _colorPreset.asStateFlow()

    private val _useDynamicAlbumColors = MutableStateFlow(true)
    val useDynamicAlbumColors = _useDynamicAlbumColors.asStateFlow()

    private val _quality = MutableStateFlow(VisualizerQuality.HIGH)
    val quality = _quality.asStateFlow()

    val rawFFT = visualizerManager.rawFFT
    val rawWaveform = visualizerManager.rawWaveform
    val beatDetected = visualizerManager.beatDetected
    val bassValue = visualizerManager.bassValue
    val trebleValue = visualizerManager.trebleValue

    init {
        viewModelScope.launch {
            settingsRepository.visEnabledFlow.collect { enabled ->
                _isEnabled.value = enabled
                visualizerManager.isEnabled = enabled
                if (!enabled) {
                    visualizerManager.release()
                }
            }
        }
        viewModelScope.launch {
            settingsRepository.visTypeFlow.collect { type ->
                _visualizerType.value = type
            }
        }
        viewModelScope.launch {
            settingsRepository.visSensitivityFlow.collect { sens ->
                _sensitivity.value = sens
                visualizerManager.sensitivity = sens
            }
        }
        viewModelScope.launch {
            settingsRepository.visFpsLimitFlow.collect { limit ->
                _fpsLimit.value = limit
                visualizerManager.fpsLimit = limit
            }
        }
        viewModelScope.launch {
            settingsRepository.visBarWidthFlow.collect { width ->
                _barWidthDp.value = width
            }
        }
        viewModelScope.launch {
            settingsRepository.visBarSpacingFlow.collect { spacing ->
                _barSpacingDp.value = spacing
            }
        }
        viewModelScope.launch {
            settingsRepository.visColorPresetFlow.collect { preset ->
                _colorPreset.value = preset
            }
        }
        viewModelScope.launch {
            settingsRepository.visDynamicColorsFlow.collect { use ->
                _useDynamicAlbumColors.value = use
            }
        }
        viewModelScope.launch {
            settingsRepository.visQualityFlow.collect { q ->
                _quality.value = q
            }
        }
    }

    fun setEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setVisEnabled(enabled)
        }
    }

    fun setVisualizerType(type: VisualizerType) {
        viewModelScope.launch {
            settingsRepository.setVisType(type)
        }
    }

    fun setSensitivity(sens: Float) {
        viewModelScope.launch {
            settingsRepository.setVisSensitivity(sens)
        }
    }

    fun setFpsLimit(limit: Int) {
        viewModelScope.launch {
            settingsRepository.setVisFpsLimit(limit)
        }
    }

    fun setBarWidth(width: Float) {
        viewModelScope.launch {
            settingsRepository.setVisBarWidth(width)
        }
    }

    fun setBarSpacing(spacing: Float) {
        viewModelScope.launch {
            settingsRepository.setVisBarSpacing(spacing)
        }
    }

    fun setColorPreset(preset: ColorPreset) {
        viewModelScope.launch {
            settingsRepository.setVisColorPreset(preset)
        }
    }

    fun setUseDynamicAlbumColors(use: Boolean) {
        viewModelScope.launch {
            settingsRepository.setVisDynamicColors(use)
        }
    }

    fun setQuality(q: VisualizerQuality) {
        viewModelScope.launch {
            settingsRepository.setVisQuality(q)
        }
    }

    fun getBandPointsByQuality(): Int {
        return when (_quality.value) {
            VisualizerQuality.LOW -> 32
            VisualizerQuality.MEDIUM -> 64
            VisualizerQuality.HIGH -> 128
            VisualizerQuality.ULTRA_HD -> 256
        }
    }

    fun updateSessionId(audioSessionId: Int) {
        if (audioSessionId != 0 && _isEnabled.value) {
            visualizerManager.updateSession(audioSessionId)
        }
    }

    fun tick(isPlaying: Boolean, progressMs: Long) {
        if (_isEnabled.value) {
            visualizerManager.tickSimulation(isPlaying, progressMs)
        }
    }

    override fun onCleared() {
        super.onCleared()
        visualizerManager.release()
    }
}
