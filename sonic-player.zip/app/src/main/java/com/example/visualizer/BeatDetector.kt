package com.example.visualizer

class BeatDetector {
    private val historySize = 30
    private val bassHistory = FloatArray(historySize)
    private val trebleHistory = FloatArray(historySize)
    private var historyIndex = 0

    var isBeat = false
        private set
    var isBassBeat = false
        private set
    var isTrebleBeat = false
        private set

    private var beatCooldownFrames = 0

    fun detect(fftMagnitudes: FloatArray) {
        if (fftMagnitudes.size < 10) {
            isBeat = false
            isBassBeat = false
            isTrebleBeat = false
            return
        }

        // Calculate Average Bass Energy (first 8% of frequency bins)
        val bassEndIdx = (fftMagnitudes.size * 0.08).toInt().coerceAtLeast(1)
        var currentBassSum = 0f
        for (i in 0 until bassEndIdx) {
            currentBassSum += fftMagnitudes[i]
        }
        val currentBassEnergy = currentBassSum / bassEndIdx

        val trebleStartIdx = (fftMagnitudes.size * 0.70).toInt()
        var currentTrebleSum = 0f
        for (i in trebleStartIdx until fftMagnitudes.size) {
            currentTrebleSum += fftMagnitudes[i]
        }
        val currentTrebleEnergy = currentTrebleSum / (fftMagnitudes.size - trebleStartIdx).coerceAtLeast(1)

        // Compute running history averages
        var bassAverage = 0f
        var trebleAverage = 0f
        for (i in 0 until historySize) {
            bassAverage += bassHistory[i]
            trebleAverage += trebleHistory[i]
        }
        bassAverage /= historySize
        trebleAverage /= historySize

        // Update History
        bassHistory[historyIndex] = currentBassEnergy
        trebleHistory[historyIndex] = currentTrebleEnergy
        historyIndex = (historyIndex + 1) % historySize

        // Detection Sensitivities
        val bassThreshold = 1.30f
        val trebleThreshold = 1.45f

        if (beatCooldownFrames > 0) {
            beatCooldownFrames--
            isBeat = false
            isBassBeat = false
            isTrebleBeat = false
        } else {
            isBassBeat = currentBassEnergy > (bassAverage * bassThreshold) && currentBassEnergy > 2.0f
            isTrebleBeat = currentTrebleEnergy > (trebleAverage * trebleThreshold) && currentTrebleEnergy > 1.5f
            isBeat = isBassBeat || isTrebleBeat
            
            if (isBeat) {
                beatCooldownFrames = 6 // Min 6 frames between beats at ~60 FPS
            }
        }
    }
}
