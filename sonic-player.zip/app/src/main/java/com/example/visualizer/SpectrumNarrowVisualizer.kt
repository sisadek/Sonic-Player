package com.example.visualizer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.visualizer.VisualizerRenderer.drawSpectrumBar
import com.example.visualizer.VisualizerRenderer.drawPeakHoldDot

@Composable
fun SpectrumNarrowVisualizer(
    fftData: FloatArray,
    colorPreset: ColorPreset,
    barWidthDp: Float = 4f,
    barSpacingDp: Float = 1.5f,
    isWide: Boolean = false,
    quality: VisualizerQuality = VisualizerQuality.HIGH,
    modifier: Modifier = Modifier
) {
    // Determine scale of frequency bands based on current preferences quality setting
    val numBands = remember(quality, isWide) {
        if (isWide) {
            when (quality) {
                VisualizerQuality.LOW -> 32
                VisualizerQuality.MEDIUM -> 64
                VisualizerQuality.HIGH -> 96
                VisualizerQuality.ULTRA_HD -> 128
            }
        } else {
            // Spectrum Narrow bands mapping (64-band, 128-band, or HD Narrow)
            when (quality) {
                VisualizerQuality.LOW -> 32
                VisualizerQuality.MEDIUM -> 64
                VisualizerQuality.HIGH -> 128
                VisualizerQuality.ULTRA_HD -> 128 // HD Mode with high spacing density
            }
        }
    }

    // Dynamic band logarithmic mapper & gravity peak hold processors
    val bandMapper = remember(numBands) { FrequencyBandMapper(numBands) }
    val peakProcessor = remember(numBands) { PeakHoldProcessor(numBands) }

    // Keep persistent state of smoothed values across frames to prevent vertical jitter
    val smoothedBands = remember(numBands) { FloatArray(numBands) }

    // Map 512 linear FFT magnitude points to logarithmic frequency bins
    val mappedBands = bandMapper.mapFftToBands(fftData)

    // Temporal smoothing: Attack rises instantly on beats, decay drifts fluidly
    val attackFactor = 0.95f // Instantly register kick drums & spikes
    val decayFactor = 0.16f  // Decay gracefully and naturally

    for (i in 0 until numBands) {
        val rawInput = mappedBands.getOrElse(i) { 0f }
        val currentSm = smoothedBands[i]
        if (rawInput > currentSm) {
            smoothedBands[i] = currentSm + (rawInput - currentSm) * attackFactor
        } else {
            smoothedBands[i] = currentSm - (currentSm - rawInput) * decayFactor
        }
    }

    // Physical peak gravity calculations
    val peaks = peakProcessor.update(smoothedBands)

    val colors = remember(colorPreset) {
        val resolved = ColorPresetResolver.getColors(colorPreset)
        listOf(resolved.first, resolved.second)
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        val baseWidth = if (quality == VisualizerQuality.ULTRA_HD) 2.2f else barWidthDp
        val baseSpacing = if (quality == VisualizerQuality.ULTRA_HD) 1.0f else barSpacingDp

        val actualBarWidth = if (isWide) (baseWidth * 1.5f).dp.toPx() else baseWidth.dp.toPx()
        val actualSpacing = if (isWide) (baseSpacing * 1.5f).dp.toPx() else baseSpacing.dp.toPx()

        val possibleBars = (width / (actualBarWidth + actualSpacing)).toInt()
        val barsToDraw = numBands.coerceAtMost(possibleBars).coerceAtLeast(16)

        val totalRequiredWidth = barsToDraw * actualBarWidth + (barsToDraw - 1) * actualSpacing
        val startX = (width - totalRequiredWidth) / 2f

        for (i in 0 until barsToDraw) {
            // Scale processed band value to nicely fit 85% of Canvas height limits
            val valIndex = smoothedBands.getOrElse(i) { 0f } * 2.2f
            val peakIndex = peaks.getOrElse(i) { 0f } * 2.2f

            val barHeight = (valIndex * height).coerceIn(4f, height * 0.88f)
            val peakHeight = (peakIndex * height).coerceIn(4f, height * 0.88f)

            val x = startX + i * (actualBarWidth + actualSpacing)

            // Draw rounded neon column
            drawSpectrumBar(
                x = x,
                width = actualBarWidth,
                height = barHeight,
                colors = colors,
                containerHeight = height
            )

            // Draw peak hold indicator cap
            if (peakHeight > barHeight + 2f) {
                drawPeakHoldDot(
                    x = x,
                    width = actualBarWidth,
                    peakHeight = peakHeight,
                    color = colors.last(),
                    containerHeight = height
                )
            }
        }
    }
}
