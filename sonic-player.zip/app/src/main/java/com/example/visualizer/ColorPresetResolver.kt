package com.example.visualizer

import androidx.compose.ui.graphics.Color

object ColorPresetResolver {
    fun getColors(preset: ColorPreset): Pair<Color, Color> {
        return when (preset) {
            ColorPreset.CYBERPUNK -> Pair(Color(0xFF00F5FF), Color(0xFFFF007F))
            ColorPreset.AURORA -> Pair(Color(0xFF39FF14), Color(0xFF00E5FF))
            ColorPreset.MONOCHROME -> Pair(Color(0xFFE2E8F0), Color(0xFF64748B))
            ColorPreset.FIRE -> Pair(Color(0xFFFF5722), Color(0xFFFFEB3B))
            ColorPreset.ELECTRIC -> Pair(Color(0xFF8B5CF6), Color(0xFFEC4899))
        }
    }
}
