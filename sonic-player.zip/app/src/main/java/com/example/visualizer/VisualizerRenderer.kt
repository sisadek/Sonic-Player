package com.example.visualizer

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope

object VisualizerRenderer {

    /**
     * Draws a single beautifully rounded vertical spectrum column with dual neon gradient blending.
     */
    fun DrawScope.drawSpectrumBar(
        x: Float,
        width: Float,
        height: Float,
        colors: List<Color>,
        containerHeight: Float
    ) {
        val topY = containerHeight - height
        val gradient = Brush.verticalGradient(
            colors = colors,
            startY = containerHeight,
            endY = topY
        )
        
        // Render stylized pill capsule bars matching Poweramp's premium design
        drawRoundRect(
            brush = gradient,
            topLeft = Offset(x, topY),
            size = Size(width, height),
            cornerRadius = CornerRadius(width / 2f, width / 2f)
        )
    }

    /**
     * Draws a falling physical peak hold dot/cap suspended beautifully above each bar.
     */
    fun DrawScope.drawPeakHoldDot(
        x: Float,
        width: Float,
        peakHeight: Float,
        color: Color,
        containerHeight: Float
    ) {
        val peakY = containerHeight - peakHeight
        val capHeight = (width / 2f).coerceAtMost(6f).coerceAtLeast(3f)
        
        drawRoundRect(
            color = color,
            topLeft = Offset(x, peakY),
            size = Size(width, capHeight),
            cornerRadius = CornerRadius(width / 2f, width / 2f)
        )
    }
}
