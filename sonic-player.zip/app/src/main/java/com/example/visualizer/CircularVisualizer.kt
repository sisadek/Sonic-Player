package com.example.visualizer

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CircularVisualizer(
    fftData: FloatArray,
    colorPreset: ColorPreset,
    modifier: Modifier = Modifier
) {
    val numPoints = 80
    val analyzer = remember { SpectrumAnalyzer(numPoints) }
    val smoothedBands = analyzer.analyzeAndSmooth(fftData, spacingFactor = 2.4f)

    val colors = remember(colorPreset) {
        val resolved = ColorPresetResolver.getColors(colorPreset)
        listOf(resolved.first, resolved.second)
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = Math.min(size.width, size.height) / 2f
        val innerRadius = (maxRadius * 0.42f).coerceAtLeast(60.dp.toPx())
        val maxBarLength = maxRadius - innerRadius - 10f

        val brush = Brush.linearGradient(
            colors = colors,
            start = Offset(center.x - innerRadius, center.y - innerRadius),
            end = Offset(center.x + innerRadius, center.y + innerRadius)
        )

        for (i in 0 until numPoints) {
            val angleDeg = (i.toFloat() / numPoints) * 360f
            val angleRad = Math.toRadians(angleDeg.toDouble())

            val amplitude = smoothedBands.getOrElse(i) { 0f }
            val barLength = (amplitude * maxBarLength).coerceIn(4f, maxBarLength)

            val startX = center.x + innerRadius * cos(angleRad).toFloat()
            val startY = center.y + innerRadius * sin(angleRad).toFloat()

            val endX = center.x + (innerRadius + barLength) * cos(angleRad).toFloat()
            val endY = center.y + (innerRadius + barLength) * sin(angleRad).toFloat()

            drawLine(
                brush = brush,
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}
