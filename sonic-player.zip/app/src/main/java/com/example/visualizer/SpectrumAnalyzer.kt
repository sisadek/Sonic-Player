package com.example.visualizer

class SpectrumAnalyzer(private val numPoints: Int) {
    private val smoothedValues = FloatArray(numPoints)
    private val peakValues = FloatArray(numPoints)
    private val decayRate = 0.08f
    private val peakDecayRate = 0.02f

    fun analyzeAndSmooth(rawFFT: FloatArray, spacingFactor: Float = 1f): FloatArray {
        val processedBands = FFTProcessor.getLogarithmicBands(rawFFT, numPoints)

        for (i in 0 until numPoints) {
            val inputVal = processedBands[i] * spacingFactor
            
            if (inputVal > smoothedValues[i]) {
                smoothedValues[i] = inputVal
            } else {
                smoothedValues[i] = (smoothedValues[i] - decayRate).coerceAtLeast(inputVal)
            }

            if (smoothedValues[i] > peakValues[i]) {
                peakValues[i] = smoothedValues[i]
            } else {
                peakValues[i] = (peakValues[i] - peakDecayRate).coerceAtLeast(0f)
            }
        }
        return smoothedValues.clone()
    }

    fun getPeakValues(): FloatArray = peakValues.clone()
}
