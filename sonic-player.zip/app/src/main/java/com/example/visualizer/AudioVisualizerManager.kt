package com.example.visualizer

import android.util.Log
import com.example.SonicPlayerApplication
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioVisualizerManager {

    private val _rawFFT = MutableStateFlow(FloatArray(512))
    val rawFFT = _rawFFT.asStateFlow()

    private val _rawWaveform = MutableStateFlow(FloatArray(128))
    val rawWaveform = _rawWaveform.asStateFlow()

    private val _beatDetected = MutableStateFlow(false)
    val beatDetected = _beatDetected.asStateFlow()

    private val _bassValue = MutableStateFlow(0f)
    val bassValue = _bassValue.asStateFlow()

    private val _trebleValue = MutableStateFlow(0f)
    val trebleValue = _trebleValue.asStateFlow()

    private val beatDetector = BeatDetector()

    var isEnabled = true
    var sensitivity = 1.0f
    var fpsLimit = 60

    // Safe thread-locked continuous circular buffer
    private val bufferLock = Any()
    private val pcmInputBuffer = FloatArray(1024)
    private var pcmBufferWriteIndex = 0
    private var isListenerRegistered = false

    init {
        registerAudioProcessorListener()
    }

    /**
     * Safely registers as a listener to receive raw high-fidelity PCM audio data from ExoPlayer.
     */
    fun registerAudioProcessorListener(): Boolean {
        if (isListenerRegistered) return true
        try {
            val app = SonicPlayerApplication.instance
            val playbackManager = app.playbackManager ?: return false
            
            playbackManager.visualizerAudioProcessor.listener = object : VisualizerAudioProcessor.OnAudioDataListener {
                override fun onAudioData(pcmData: ShortArray, channelCount: Int, sampleRate: Int) {
                    if (!isEnabled) return
                    
                    synchronized(bufferLock) {
                        for (i in pcmData.indices step channelCount) {
                            var sum = 0f
                            var count = 0
                            for (c in 0 until channelCount) {
                                val idx = i + c
                                if (idx < pcmData.size) {
                                    sum += pcmData[idx] / 32768.5f
                                    count++
                                }
                            }
                            val monoVal = if (count > 0) sum / count else 0f
                            
                            pcmInputBuffer[pcmBufferWriteIndex] = monoVal
                            pcmBufferWriteIndex = (pcmBufferWriteIndex + 1) % pcmInputBuffer.size
                        }
                    }
                }
            }
            isListenerRegistered = true
            Log.d("AudioVisualizerManager", "Successfully registered visualizer on Media3 PCM Audio Processor")
            return true
        } catch (e: Exception) {
            Log.e("AudioVisualizerManager", "Error binding custom AudioProcessor listener: ${e.message}")
            return false
        }
    }

    /**
     * Executes true real-time calculations from our buffered audio PCM streaming.
     */
    fun performFftAnalysis() {
        if (!isEnabled) return
        
        // Ensure listener is connected
        if (!isListenerRegistered) {
            registerAudioProcessorListener()
        }

        val localPcm = FloatArray(1024)
        synchronized(bufferLock) {
            var reader = pcmBufferWriteIndex
            for (i in 0 until 1024) {
                localPcm[i] = pcmInputBuffer[reader]
                reader = (reader + 1) % pcmInputBuffer.size
            }
        }

        // Apply visual scale sensitivity factor
        for (i in localPcm.indices) {
            localPcm[i] *= sensitivity
        }

        // Compute true Cooley-Tukey FFT magnitudes on real PCM data
        val rawMagnitudes = FFTProcessor.calculateMagnitudes(localPcm)

        val scaledWaveform = FloatArray(128) { i ->
            val srcIdx = (i * (1024 / 128)).coerceIn(localPcm.indices)
            localPcm[srcIdx]
        }

        _rawWaveform.value = scaledWaveform

        // Analyze beat characteristics
        beatDetector.detect(rawMagnitudes)
        _beatDetected.value = beatDetector.isBeat

        // Standard Bass and Treble estimates
        if (rawMagnitudes.size >= 32) {
            _bassValue.value = rawMagnitudes.take(16).average().toFloat()
            _trebleValue.value = rawMagnitudes.takeLast(32).average().toFloat()
        }

        _rawFFT.value = rawMagnitudes
    }

    /**
     * Core reactive step. Compares state to playback progress and triggers recalculation.
     */
    fun tickSimulation(isPlaying: Boolean, progressMs: Long) {
        if (!isEnabled) return

        if (isPlaying) {
            performFftAnalysis()
        } else {
            smoothDecayToZero()
        }
    }

    private fun smoothDecayToZero() {
        val extFft = _rawFFT.value
        if (extFft.any { it > 0.001f }) {
            val decayed = FloatArray(extFft.size) { i ->
                (extFft[i] * 0.85f).coerceAtLeast(0f)
            }
            _rawFFT.value = decayed
        }
        
        val extWave = _rawWaveform.value
        if (extWave.any { Math.abs(it) > 0.001f }) {
            val decayed = FloatArray(extWave.size) { i ->
                extWave[i] * 0.85f
            }
            _rawWaveform.value = decayed
        }

        _beatDetected.value = false
        _bassValue.value = 0f
        _trebleValue.value = 0f
    }

    fun updateSession(sessionId: Int) {
        // Direct PCM callback used instead of dangerous session ID polling
    }

    fun release() {
        isListenerRegistered = false
    }
}
