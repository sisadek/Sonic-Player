package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.ui.screens.SonicMasterLayout
import com.example.ui.theme.SonicPlayerTheme
import com.example.ui.theme.SonicThemeType
import com.example.ui.viewmodel.MusicViewModel

class MainActivity : ComponentActivity() {

    // Initialize our Master Reactive ViewModel
    private val musicViewModel: MusicViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Supports full edge-to-edge transparent drawing
        enableEdgeToEdge()

        setContent {
            val settingsRepository = remember { SonicPlayerApplication.instance.settingsRepository }
            // Theme Level selector state (Dark Navy, Black AMOLED or Light Blue-Gray)
            val themeTypeState = remember { mutableStateOf(SonicThemeType.DARK) }

            // 1. Collect and sync from DataStore
            LaunchedEffect(Unit) {
                settingsRepository.themeFlow.collect { theme ->
                    themeTypeState.value = theme
                }
            }

            // 2. Sync changes back to DataStore
            LaunchedEffect(themeTypeState.value) {
                settingsRepository.setTheme(themeTypeState.value)
            }

            SonicPlayerTheme(themeType = themeTypeState.value) {
                SonicMasterLayout(
                    viewModel = musicViewModel,
                    themeTypeState = themeTypeState,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}
