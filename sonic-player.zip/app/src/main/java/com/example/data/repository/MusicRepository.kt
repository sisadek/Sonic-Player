package com.example.data.repository

import com.example.data.local.SongDao
import com.example.data.local.SongEntity
import com.example.data.local.PlaylistEntity
import com.example.data.local.PlaylistSongCrossRef
import com.example.data.local.RecentlyPlayedEntity
import com.example.data.local.DownloadEntity
import com.example.domain.model.Song
import com.example.domain.model.SyncedLine
import com.example.domain.model.Playlist
import com.example.domain.model.Album
import com.example.domain.model.Artist
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class MusicRepository(private val songDao: SongDao) {

    // Helper to map Sync lyrics from string to domain
    private fun parseSyncedLyrics(raw: String?): List<SyncedLine> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            raw.split("||").mapNotNull { block ->
                val parts = block.split("::", limit = 2)
                if (parts.size == 2) {
                    SyncedLine(parts[0].toLong(), parts[1])
                } else null
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun serializeSyncedLyrics(lines: List<SyncedLine>): String {
        return lines.joinToString("||") { "${it.timeMs}::${it.text}" }
    }

    private fun mapToDomain(entity: SongEntity): Song {
        return Song(
            id = entity.id,
            title = entity.title,
            artist = entity.artist,
            album = entity.album,
            duration = entity.duration,
            uriStr = entity.uriStr,
            isFavorite = entity.isFavorite,
            lyrics = entity.lyrics,
            syncedLyrics = parseSyncedLyrics(entity.syncedLyricsJson)
        )
    }

    private fun mapToEntity(domain: Song): SongEntity {
        return SongEntity(
            id = domain.id,
            title = domain.title,
            artist = domain.artist,
            album = domain.album,
            duration = domain.duration,
            uriStr = domain.uriStr,
            isFavorite = domain.isFavorite,
            lyrics = domain.lyrics,
            syncedLyricsJson = serializeSyncedLyrics(domain.syncedLyrics)
        )
    }

    // Song operations
    fun getAllSongs(): Flow<List<Song>> = songDao.getAllSongs().map { list -> list.map { mapToDomain(it) } }

    suspend fun insertSongs(songs: List<Song>) {
        songDao.insertSongs(songs.map { mapToEntity(it) })
    }

    suspend fun updateFavorite(songId: String, isFavorite: Boolean) {
        songDao.updateFavorite(songId, isFavorite)
    }

    fun getFavoriteSongs(): Flow<List<Song>> = songDao.getFavoriteSongs().map { list -> list.map { mapToDomain(it) } }

    // Playlist operations
    fun getAllPlaylists(): Flow<List<Playlist>> = songDao.getAllPlaylists().map { playlists ->
        playlists.map { Playlist(it.id, it.name, 0) }
    }

    suspend fun createPlaylist(name: String) {
        val id = UUID.randomUUID().toString()
        songDao.insertPlaylist(PlaylistEntity(id, name))
    }

    suspend fun deletePlaylist(playlistId: String) {
        songDao.deletePlaylist(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: String, songId: String) {
        songDao.insertPlaylistSong(PlaylistSongCrossRef(playlistId, songId))
    }

    suspend fun removeSongFromPlaylist(playlistId: String, songId: String) {
        songDao.removeSongFromPlaylist(playlistId, songId)
    }

    fun getSongsForPlaylist(playlistId: String): Flow<List<Song>> = songDao.getSongsForPlaylist(playlistId).map { list ->
        list.map { mapToDomain(it) }
    }

    // Recently Played
    suspend fun addToRecentlyPlayed(songId: String) {
        songDao.insertRecentlyPlayed(RecentlyPlayedEntity(songId, System.currentTimeMillis()))
    }

    fun getRecentlyPlayed(): Flow<List<Song>> = songDao.getRecentlyPlayed().map { list ->
        list.map { mapToDomain(it) }
    }

    // Extra computed lists
    fun getAlbums(): Flow<List<Album>> = getAllSongs().map { songs ->
        songs.groupBy { it.album }.map { (albumTitle, tracks) ->
            Album(
                title = albumTitle,
                artist = tracks.firstOrNull()?.artist ?: "Unknown Artist",
                trackCount = tracks.size
            )
        }
    }

    fun getArtists(): Flow<List<Artist>> = getAllSongs().map { songs ->
        songs.groupBy { it.artist }.map { (artistName, tracks) ->
            Artist(
                name = artistName,
                trackCount = tracks.size
            )
        }
    }
}
