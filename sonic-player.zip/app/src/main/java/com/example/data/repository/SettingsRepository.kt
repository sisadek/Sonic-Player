package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.SonicThemeType
import com.example.visualizer.VisualizerType
import com.example.visualizer.VisualizerQuality
import com.example.visualizer.ColorPreset
import com.example.service.PlaybackMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "sonic_player_settings")

class SettingsRepository(private val context: Context) {

    private val dataStore = context.dataStore

    companion object {
        val KEY_THEME = stringPreferencesKey("theme_type")
        
        // Visualizer
        val KEY_VIS_ENABLED = booleanPreferencesKey("visualizer_enabled")
        val KEY_VIS_TYPE = stringPreferencesKey("visualizer_type")
        val KEY_VIS_SENSITIVITY = floatPreferencesKey("visualizer_sensitivity")
        val KEY_VIS_FPS_LIMIT = intPreferencesKey("visualizer_fps_limit")
        val KEY_VIS_BAR_WIDTH = floatPreferencesKey("visualizer_bar_width")
        val KEY_VIS_BAR_SPACING = floatPreferencesKey("visualizer_bar_spacing")
        val KEY_VIS_COLOR_PRESET = stringPreferencesKey("visualizer_color_preset")
        val KEY_VIS_DYNAMIC_COLORS = booleanPreferencesKey("visualizer_dynamic_colors")
        val KEY_VIS_QUALITY = stringPreferencesKey("visualizer_quality")

        // Playback
        val KEY_PLAYBACK_MODE = stringPreferencesKey("playback_mode")
        val KEY_PLAYBACK_SPEED = floatPreferencesKey("playback_speed")

        // Equalizer
        val KEY_BASS_BOOST = intPreferencesKey("bass_boost_strength")
        fun eqBandKey(bandIndex: Int) = intPreferencesKey("eq_band_$bandIndex")

        // Sleep Timer
        val KEY_SLEEP_TIMER_END_TIME = longPreferencesKey("sleep_timer_end_time")
        val KEY_LAST_SLEEP_MINUTES = intPreferencesKey("last_sleep_minutes")
    }

    // Get Flows
    val themeFlow: Flow<SonicThemeType> = dataStore.data.map { prefs ->
        val name = prefs[KEY_THEME] ?: SonicThemeType.DARK.name
        try { SonicThemeType.valueOf(name) } catch (e: Exception) { SonicThemeType.DARK }
    }

    // Visualizer settings flows
    val visEnabledFlow: Flow<Boolean> = dataStore.data.map { it[KEY_VIS_ENABLED] ?: true }
    val visTypeFlow: Flow<VisualizerType> = dataStore.data.map { prefs ->
        val name = prefs[KEY_VIS_TYPE] ?: VisualizerType.SPECTRUM_NARROW.name
        try { VisualizerType.valueOf(name) } catch (e: Exception) { VisualizerType.SPECTRUM_NARROW }
    }
    val visSensitivityFlow: Flow<Float> = dataStore.data.map { it[KEY_VIS_SENSITIVITY] ?: 1.0f }
    val visFpsLimitFlow: Flow<Int> = dataStore.data.map { it[KEY_VIS_FPS_LIMIT] ?: 60 }
    val visBarWidthFlow: Flow<Float> = dataStore.data.map { it[KEY_VIS_BAR_WIDTH] ?: 4f }
    val visBarSpacingFlow: Flow<Float> = dataStore.data.map { it[KEY_VIS_BAR_SPACING] ?: 2f }
    val visColorPresetFlow: Flow<ColorPreset> = dataStore.data.map { prefs ->
        val name = prefs[KEY_VIS_COLOR_PRESET] ?: ColorPreset.CYBERPUNK.name
        try { ColorPreset.valueOf(name) } catch (e: Exception) { ColorPreset.CYBERPUNK }
    }
    val visDynamicColorsFlow: Flow<Boolean> = dataStore.data.map { it[KEY_VIS_DYNAMIC_COLORS] ?: true }
    val visQualityFlow: Flow<VisualizerQuality> = dataStore.data.map { prefs ->
        val name = prefs[KEY_VIS_QUALITY] ?: VisualizerQuality.HIGH.name
        try { VisualizerQuality.valueOf(name) } catch (e: Exception) { VisualizerQuality.HIGH }
    }

    // Playback flows
    val playbackModeFlow: Flow<PlaybackMode> = dataStore.data.map { prefs ->
        val name = prefs[KEY_PLAYBACK_MODE] ?: PlaybackMode.REPEAT_ALL.name
        try { PlaybackMode.valueOf(name) } catch (e: Exception) { PlaybackMode.REPEAT_ALL }
    }
    val playbackSpeedFlow: Flow<Float> = dataStore.data.map { it[KEY_PLAYBACK_SPEED] ?: 1.0f }

    // Equalizer
    val bassBoostFlow: Flow<Int> = dataStore.data.map { it[KEY_BASS_BOOST] ?: 0 }
    fun eqBandFlow(bandIndex: Int): Flow<Int> = dataStore.data.map { it[eqBandKey(bandIndex)] ?: 0 }

    // Sleep Timer
    val sleepTimerEndTimeFlow: Flow<Long> = dataStore.data.map { it[KEY_SLEEP_TIMER_END_TIME] ?: 0L }
    val lastSleepMinutesFlow: Flow<Int> = dataStore.data.map { it[KEY_LAST_SLEEP_MINUTES] ?: 0 }

    // Setters
    suspend fun setTheme(theme: SonicThemeType) {
        dataStore.edit { it[KEY_THEME] = theme.name }
    }

    suspend fun setVisEnabled(enabled: Boolean) {
        dataStore.edit { it[KEY_VIS_ENABLED] = enabled }
    }

    suspend fun setVisType(type: VisualizerType) {
        dataStore.edit { it[KEY_VIS_TYPE] = type.name }
    }

    suspend fun setVisSensitivity(sensitivity: Float) {
        dataStore.edit { it[KEY_VIS_SENSITIVITY] = sensitivity }
    }

    suspend fun setVisFpsLimit(fps: Int) {
        dataStore.edit { it[KEY_VIS_FPS_LIMIT] = fps }
    }

    suspend fun setVisBarWidth(width: Float) {
        dataStore.edit { it[KEY_VIS_BAR_WIDTH] = width }
    }

    suspend fun setVisBarSpacing(spacing: Float) {
        dataStore.edit { it[KEY_VIS_BAR_SPACING] = spacing }
    }

    suspend fun setVisColorPreset(preset: ColorPreset) {
        dataStore.edit { it[KEY_VIS_COLOR_PRESET] = preset.name }
    }

    suspend fun setVisDynamicColors(enabled: Boolean) {
        dataStore.edit { it[KEY_VIS_DYNAMIC_COLORS] = enabled }
    }

    suspend fun setVisQuality(quality: VisualizerQuality) {
        dataStore.edit { it[KEY_VIS_QUALITY] = quality.name }
    }

    suspend fun setPlaybackMode(mode: PlaybackMode) {
        dataStore.edit { it[KEY_PLAYBACK_MODE] = mode.name }
    }

    suspend fun setPlaybackSpeed(speed: Float) {
        dataStore.edit { it[KEY_PLAYBACK_SPEED] = speed }
    }

    suspend fun setBassBoost(strength: Int) {
        dataStore.edit { it[KEY_BASS_BOOST] = strength }
    }

    suspend fun setEqBand(bandIndex: Int, level: Int) {
        dataStore.edit { it[eqBandKey(bandIndex)] = level }
    }

    suspend fun setSleepTimerEndTime(endTimeMs: Long) {
        dataStore.edit { it[KEY_SLEEP_TIMER_END_TIME] = endTimeMs }
    }

    suspend fun setLastSleepMinutes(minutes: Int) {
        dataStore.edit { it[KEY_LAST_SLEEP_MINUTES] = minutes }
    }
}
