package com.example.utils

import android.content.Context
import android.provider.MediaStore
import com.example.domain.model.Song
import com.example.domain.model.SyncedLine

object MediaStoreScanner {

    // Seeding Premium Mock Tracks with real stream URLs & synced lyrics
    val SEEDED_TRACKS = listOf(
        Song(
            id = "seed_1",
            title = "Synthwave Horizon",
            artist = "Sadek Prime",
            album = "Futuristic Retro",
            duration = 372000, // 6:12
            uriStr = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
            lyrics = "Welcome to the Synthwave Horizon. Cruise down the highway... under neon light.\nFeel the synthetic wind of futuristic retrospect.",
            syncedLyrics = listOf(
                SyncedLine(0, "[Intro - Retro Synths]"),
                SyncedLine(4000, "Cruising down the gridline road"),
                SyncedLine(8000, "Neon stars are shining bright"),
                SyncedLine(12000, "We are traveling to the horizon"),
                SyncedLine(16000, "Enter Mr Sadek World's premium rhythm"),
                SyncedLine(20000, "Feel the bass boost pumping through your veins"),
                SyncedLine(24000, "Cyan lasers intersecting in the dark"),
                SyncedLine(28000, "We are moving, yes, we're moving fast"),
                SyncedLine(32000, "Under the beautiful cyber sunset")
            )
        ),
        Song(
            id = "seed_2",
            title = "Starlight Overdrive",
            artist = "Nebula Drive",
            album = "Cosmos Chronicles",
            duration = 423000, // 7:03
            uriStr = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
            lyrics = "Floating through cosmic clouds... starlight engine engaged.\nSpeed of light is just the beginning.",
            syncedLyrics = listOf(
                SyncedLine(0, "[Opening - Cosmic Atmospheres]"),
                SyncedLine(5000, "Ignition: Starlight Overdrive active!"),
                SyncedLine(9000, "Passing Saturn's glowing rings of dust"),
                SyncedLine(13000, "Deep space echoes in our ears"),
                SyncedLine(17000, "Mr Sadek World's pilot navigation is online"),
                SyncedLine(21000, "Seeking galaxies yet to be named"),
                SyncedLine(25000, "The universe is playing on our screen"),
                SyncedLine(29000, "[Deep bass vibration]")
            )
        ),
        Song(
            id = "seed_3",
            title = "Cyberpunk Echoes",
            artist = "Mr Sadek World",
            album = "Sonic Revolution",
            duration = 344000, // 5:44
            uriStr = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
            lyrics = "Developed by Mr Sadek World. Experience the ultimate sonic performance.\nThis is the cyber revolutionary anthem.",
            syncedLyrics = listOf(
                SyncedLine(0, "[Sonic Player Anthem - Beat Drops]"),
                SyncedLine(4000, "Mr Sadek World presents: Sonic Player!"),
                SyncedLine(8000, "Navy blue themes surrounding our device"),
                SyncedLine(12000, "Glassmorphism aesthetics feeling so premium"),
                SyncedLine(16000, "Hardware equalizer tuned perfectly in sync"),
                SyncedLine(20000, "Yes! We are enjoying the cyber freedom"),
                SyncedLine(24000, "No lags, no drops, pure digital stream"),
                SyncedLine(28000, "[Guitar Solo - Amplified!]")
            )
        ),
        Song(
            id = "seed_4",
            title = "Velvet Nocturne",
            artist = "Moonlight Suite",
            album = "Nightscape Chronicles",
            duration = 302000,
            uriStr = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
            lyrics = "Soft keys under the midnight moon. Serenity takes over.",
            syncedLyrics = listOf(
                SyncedLine(0, "[Somatic Piano Solo]"),
                SyncedLine(5000, "Whispers of the night wind"),
                SyncedLine(10000, "Under the velvet indigo sky"),
                SyncedLine(15000, "A quiet relaxation comes to life"),
                SyncedLine(20000, "Sonic Player sleep timer is set and ticking"),
                SyncedLine(25000, "Rest your mind, let the rhythm float")
            )
        )
    )

    fun scanDeviceSongs(context: Context): List<Song> {
        val songList = mutableListOf<Song>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                null,
                null
            )
            
            cursor?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val pathCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)

                while (c.moveToNext()) {
                    val id = c.getLong(idCol).toString()
                    val title = c.getString(titleCol) ?: "Unknown Song"
                    val artist = c.getString(artistCol) ?: "Unknown Artist"
                    val album = c.getString(albumCol) ?: "Unknown Album"
                    val duration = c.getLong(durationCol)
                    val path = c.getString(pathCol)

                    songList.add(
                        Song(
                            id = id,
                            title = title,
                            artist = artist,
                            album = album,
                            duration = duration,
                            uriStr = path,
                            lyrics = "No local lyrics loaded"
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Return local list, fallback to seeds if empty
        return songList.ifEmpty { SEEDED_TRACKS }
    }
}
