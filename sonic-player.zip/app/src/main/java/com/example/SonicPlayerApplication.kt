package com.example

import android.app.Application
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.repository.MusicRepository
import com.example.data.repository.SettingsRepository
import com.example.service.PlaybackManager

class SonicPlayerApplication : Application() {

    lateinit var database: AppDatabase
    lateinit var musicRepository: MusicRepository
    lateinit var settingsRepository: SettingsRepository
    lateinit var playbackManager: PlaybackManager

    override fun onCreate() {
        super.onCreate()
        instance = this

        // 0. SettingsRepository Initialization
        settingsRepository = SettingsRepository(applicationContext)

        // 1. AppDatabase Initialization
        database = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "sonic_player_database"
        ).fallbackToDestructiveMigration()
         .build()

        // 2. Repository Injection
        musicRepository = MusicRepository(database.songDao())

        // 3. Playback Manager Initialization
        playbackManager = PlaybackManager(applicationContext)
    }

    companion object {
        lateinit var instance: SonicPlayerApplication
            private set
    }
}
