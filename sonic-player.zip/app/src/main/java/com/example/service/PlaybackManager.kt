package com.example.service

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.example.visualizer.VisualizerAudioProcessor
import com.example.SonicPlayerApplication
import com.example.domain.model.Song
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

enum class PlaybackMode {
    REPEAT_ALL, REPEAT_ONE, SHUFFLE
}

class PlaybackManager(private val context: Context) : Player.Listener {

    val visualizerAudioProcessor = VisualizerAudioProcessor()

    private var exoPlayer: ExoPlayer? = null
    private var handler: Handler = Handler(Looper.getMainLooper())
    private var isTrackingProgress = false

    // System Audio FX
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    private val settingsRepository = SonicPlayerApplication.instance.settingsRepository
    private val scope = CoroutineScope(Dispatchers.Main)

    // State flows representing actual engine states
    private val _currentSong = MutableStateFlow<Song?>(null)
    val currentSong = _currentSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying = _isPlaying.asStateFlow()

    private val _currentPosition = MutableStateFlow(0L)
    val currentPosition = _currentPosition.asStateFlow()

    private val _currentQueue = MutableStateFlow<List<Song>>(emptyList())
    val currentQueue = _currentQueue.asStateFlow()

    private val _playbackMode = MutableStateFlow(PlaybackMode.REPEAT_ALL)
    val playbackMode = _playbackMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed = _playbackSpeed.asStateFlow()

    private val _bassBoostStrength = MutableStateFlow(0) // 0 - 1000
    val bassBoostStrength = _bassBoostStrength.asStateFlow()

    private val _eqEnabled = MutableStateFlow(false)
    val eqEnabled = _eqEnabled.asStateFlow()

    // Lyrics State
    private val _currentSyncedLyricLine = MutableStateFlow("")
    val currentSyncedLyricLine = _currentSyncedLyricLine.asStateFlow()

    // Sleep Timer
    private val _sleepTimerMsLeft = MutableStateFlow(0L)
    val sleepTimerMsLeft = _sleepTimerMsLeft.asStateFlow()
    private var sleepRunnable: Runnable? = null

    init {
        initializePlayer()
        loadPersistedSettings()
    }

    private fun initializePlayer() {
        if (exoPlayer != null) return
        
        val renderersFactory = object : DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink? {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(visualizerAudioProcessor))
                    .build()
            }
        }

        exoPlayer = ExoPlayer.Builder(context, renderersFactory).build().apply {
            addListener(this@PlaybackManager)
            repeatMode = Player.REPEAT_MODE_ALL
        }

        // Initialize EQ once player starts audio track
        setupAudioEffects()
        startTrackingProgress()
    }

    private fun loadPersistedSettings() {
        scope.launch {
            settingsRepository.playbackModeFlow.collect { mode ->
                _playbackMode.value = mode
                updateExoPlayerRepeatMode(mode)
            }
        }
        scope.launch {
            settingsRepository.playbackSpeedFlow.collect { speed ->
                _playbackSpeed.value = speed
                exoPlayer?.playbackParameters = PlaybackParameters(speed)
            }
        }
        scope.launch {
            settingsRepository.bassBoostFlow.collect { strength ->
                _bassBoostStrength.value = strength
                applyBassBoostStrength(strength)
            }
        }
        scope.launch {
            val endTime = settingsRepository.sleepTimerEndTimeFlow.first()
            val now = System.currentTimeMillis()
            if (endTime > now) {
                val remainingMs = endTime - now
                val minutes = (remainingMs / 1000 / 60).toInt().coerceAtLeast(1)
                startSleepTimer(minutes)
            }
        }
    }

    private fun updateExoPlayerRepeatMode(mode: PlaybackMode) {
        exoPlayer?.let { player ->
            when (mode) {
                PlaybackMode.REPEAT_ALL -> player.repeatMode = Player.REPEAT_MODE_ALL
                PlaybackMode.REPEAT_ONE -> player.repeatMode = Player.REPEAT_MODE_ONE
                PlaybackMode.SHUFFLE -> player.repeatMode = Player.REPEAT_MODE_ALL
            }
        }
    }

    private fun applyBassBoostStrength(strength: Int) {
        try {
            bassBoost?.let {
                if (!it.enabled) it.enabled = true
                it.setStrength(strength.toShort())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun setupAudioEffects() {
        val player = exoPlayer ?: return
        val sessionId = player.audioSessionId
        if (sessionId != 0) {
            try {
                equalizer = Equalizer(0, sessionId).apply {
                    enabled = true
                    scope.launch {
                        val count = numberOfBands.toInt()
                        for (i in 0 until count) {
                            settingsRepository.eqBandFlow(i).collect { level ->
                                setBandLevel(i.toShort(), level.toShort())
                            }
                        }
                    }
                }
                bassBoost = BassBoost(0, sessionId).apply {
                    enabled = true
                    scope.launch {
                        settingsRepository.bassBoostFlow.collect { strength ->
                            setStrength(strength.toShort())
                        }
                    }
                }
                _eqEnabled.value = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun setBassBoost(strength: Int) {
        val bounded = strength.coerceIn(0, 1000)
        _bassBoostStrength.value = bounded
        applyBassBoostStrength(bounded)
        scope.launch {
            settingsRepository.setBassBoost(bounded)
        }
    }

    fun setEqBandLevel(band: Int, level: Short) {
        try {
            equalizer?.setBandLevel(band.toShort(), level)
            scope.launch {
                settingsRepository.setEqBand(band, level.toInt())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getEqBands(): List<String> {
        val eq = equalizer ?: return emptyList()
        val bands = mutableListOf<String>()
        try {
            val count = eq.numberOfBands.toInt()
            for (i in 0 until count) {
                val freq = eq.getCenterFreq(i.toShort()) / 1000 // In Hz
                bands.add("${freq}Hz")
            }
        } catch (e: Exception) {
            return listOf("60Hz", "230Hz", "910Hz", "4kHz", "14kHz")
        }
        return bands
    }

    fun getBandLevelRange(): IntArray {
        return try {
            val range = equalizer?.bandLevelRange ?: shortArrayOf(-1500, 1500)
            intArrayOf(range[0].toInt(), range[1].toInt())
        } catch (e: Exception) {
            intArrayOf(-1500, 1500)
        }
    }

    private fun startTrackingProgress() {
        if (isTrackingProgress) return
        isTrackingProgress = true
        
        val progressRunnable = object : Runnable {
            override fun run() {
                val player = exoPlayer
                if (player != null && player.isPlaying) {
                    _currentPosition.value = player.currentPosition
                    updateSyncedLyrics(player.currentPosition)
                }
                handler.postDelayed(this, 100)
            }
        }
        handler.post(progressRunnable)
    }

    private fun updateSyncedLyrics(currentTimeMs: Long) {
        val song = _currentSong.value ?: return
        if (song.syncedLyrics.isEmpty()) {
            _currentSyncedLyricLine.value = ""
            return
        }
        val matchingLine = song.syncedLyrics
            .lastOrNull { it.timeMs <= currentTimeMs }
        _currentSyncedLyricLine.value = matchingLine?.text ?: ""
    }

    // Controls
    fun setQueue(songs: List<Song>, startIndex: Int = 0) {
        _currentQueue.value = songs
        val player = exoPlayer ?: return
        player.clearMediaItems()
        
        songs.forEach { song ->
            val mediaItem = MediaItem.Builder()
                .setMediaId(song.id)
                .setUri(Uri.parse(song.uriStr))
                .build()
            player.addMediaItem(mediaItem)
        }

        if (songs.isNotEmpty()) {
            try {
                player.seekTo(startIndex.coerceIn(0, songs.size - 1), 0L)
                _currentSong.value = songs[startIndex.coerceIn(0, songs.size - 1)]
                player.prepare()
                player.play()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun play() {
        val player = exoPlayer ?: return
        // Try creating session ID effects if not loaded yet
        if (equalizer == null) {
            setupAudioEffects()
        }
        player.play()
    }

    fun pause() {
        exoPlayer?.pause()
    }

    fun togglePlayPause() {
        val player = exoPlayer ?: return
        if (player.isPlaying) {
            player.pause()
        } else {
            play()
        }
    }

    fun next() {
        val queue = _currentQueue.value
        val current = _currentSong.value
        if (queue.isEmpty() || current == null) return

        val index = queue.indexOfFirst { it.id == current.id }
        if (index != -1) {
            val nextIndex = if (_playbackMode.value == PlaybackMode.SHUFFLE) {
                queue.indices.random()
            } else {
                (index + 1) % queue.size
            }
            seekToQueueIndex(nextIndex)
        }
    }

    fun previous() {
        val queue = _currentQueue.value
        val current = _currentSong.value
        if (queue.isEmpty() || current == null) return

        val index = queue.indexOfFirst { it.id == current.id }
        if (index != -1) {
            val prevIndex = if (index - 1 < 0) queue.size - 1 else index - 1
            seekToQueueIndex(prevIndex)
        }
    }

    private fun seekToQueueIndex(index: Int) {
        val queue = _currentQueue.value
        if (index in queue.indices) {
            val nextSong = queue[index]
            _currentSong.value = nextSong
            exoPlayer?.let { player ->
                player.seekTo(index, 0L)
                player.prepare()
                player.play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        _currentPosition.value = positionMs
        exoPlayer?.seekTo(positionMs)
    }

    fun setSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.25f, 2.0f)
        _playbackSpeed.value = clamped
        exoPlayer?.playbackParameters = PlaybackParameters(clamped)
        scope.launch {
            settingsRepository.setPlaybackSpeed(clamped)
        }
    }

    fun togglePlaybackMode() {
        val nextMode = when (_playbackMode.value) {
            PlaybackMode.REPEAT_ALL -> {
                exoPlayer?.repeatMode = Player.REPEAT_MODE_ONE
                PlaybackMode.REPEAT_ONE
            }
            PlaybackMode.REPEAT_ONE -> {
                PlaybackMode.REPEAT_ALL
                PlaybackMode.SHUFFLE
            }
            PlaybackMode.SHUFFLE -> {
                exoPlayer?.repeatMode = Player.REPEAT_MODE_ALL
                PlaybackMode.REPEAT_ALL
            }
        }
        _playbackMode.value = nextMode
        scope.launch {
            settingsRepository.setPlaybackMode(nextMode)
        }
    }

    fun startSleepTimer(minutes: Int) {
        stopSleepTimer()
        if (minutes <= 0) return

        val ms = minutes * 60 * 1000L
        _sleepTimerMsLeft.value = ms

        val targetEndTime = System.currentTimeMillis() + ms
        scope.launch {
            settingsRepository.setSleepTimerEndTime(targetEndTime)
            settingsRepository.setLastSleepMinutes(minutes)
        }

        sleepRunnable = object : Runnable {
            override fun run() {
                val currentLeft = _sleepTimerMsLeft.value
                if (currentLeft <= 1000L) {
                    _sleepTimerMsLeft.value = 0L
                    pause()
                    scope.launch {
                        settingsRepository.setSleepTimerEndTime(0)
                    }
                } else {
                    _sleepTimerMsLeft.value = currentLeft - 1000L
                    handler.postDelayed(this, 1000L)
                }
            }
        }
        handler.postDelayed(sleepRunnable!!, 1000L)
    }

    fun stopSleepTimer() {
        sleepRunnable?.let { handler.removeCallbacks(it) }
        sleepRunnable = null
        _sleepTimerMsLeft.value = 0L
        scope.launch {
            settingsRepository.setSleepTimerEndTime(0)
        }
    }

    fun getAudioSessionId(): Int = exoPlayer?.audioSessionId ?: 0

    // Media3 overrides
    override fun onIsPlayingChanged(isPlaying: Boolean) {
        _isPlaying.value = isPlaying
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        val mediaId = mediaItem?.mediaId ?: return
        val currentQueueSongs = _currentQueue.value
        val song = currentQueueSongs.find { it.id == mediaId }
        if (song != null) {
            _currentSong.value = song
        }
    }
}
