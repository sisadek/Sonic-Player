package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

enum class SonicThemeType {
  LIGHT, DARK, AMOLED
}

private val DarkColorScheme =
  darkColorScheme(
    primary = SonicCyanAccent,
    secondary = SonicCyanBright,
    tertiary = SonicPurpleAccent,
    background = SonicDeepNavy,
    surface = SonicNavyMain,
    onPrimary = SonicDeepNavy,
    onSecondary = SonicDeepNavy,
    onTertiary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
  )

private val AmoledColorScheme =
  darkColorScheme(
    primary = SonicCyanAccent,
    secondary = SonicCyanBright,
    tertiary = SonicPurpleAccent,
    background = Color.Black,
    surface = SonicDeepNavy,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
  )

private val LightColorScheme =
  lightColorScheme(
    primary = SonicCyanMuted,
    secondary = SonicPurpleAccent,
    tertiary = SonicCyanBright,
    background = SonicLightBg,
    surface = SonicLightSurface,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.Black,
    onBackground = SonicLightText,
    onSurface = SonicLightText,
  )

@Composable
fun SonicPlayerTheme(
  themeType: SonicThemeType = SonicThemeType.DARK,
  dynamicColor: Boolean = false, // Set to false to enforce official branding
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (themeType == SonicThemeType.LIGHT) dynamicLightColorScheme(context) else dynamicDarkColorScheme(context)
    }
    themeType == SonicThemeType.AMOLED -> AmoledColorScheme
    themeType == SonicThemeType.LIGHT -> LightColorScheme
    else -> DarkColorScheme
  }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  SonicPlayerTheme(
    themeType = if (darkTheme) SonicThemeType.DARK else SonicThemeType.LIGHT,
    dynamicColor = dynamicColor,
    content = content
  )
}
