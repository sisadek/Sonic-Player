package com.example.ui.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.SonicPlayerApplication
import com.example.data.repository.MusicRepository
import com.example.domain.model.Album
import com.example.domain.model.Artist
import com.example.domain.model.Playlist
import com.example.domain.model.Song
import com.example.service.PlaybackManager
import com.example.service.PlaybackMode
import com.example.utils.MediaStoreScanner
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MusicViewModel : ViewModel() {

    private val repository: MusicRepository = SonicPlayerApplication.instance.musicRepository
    private val playbackManager: PlaybackManager = SonicPlayerApplication.instance.playbackManager

    // Database Streams
    val allSongs: StateFlow<List<Song>> = repository.getAllSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoriteSongs: StateFlow<List<Song>> = repository.getFavoriteSongs()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val playlists: StateFlow<List<Playlist>> = repository.getAllPlaylists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val albums: StateFlow<List<Album>> = repository.getAlbums()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val artists: StateFlow<List<Artist>> = repository.getArtists()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayed: StateFlow<List<Song>> = repository.getRecentlyPlayed()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Engine playback values mapped from PlaybackManager
    val currentSong: StateFlow<Song?> = playbackManager.currentSong
    val isPlaying: StateFlow<Boolean> = playbackManager.isPlaying
    val currentPosition: StateFlow<Long> = playbackManager.currentPosition
    val currentQueue: StateFlow<List<Song>> = playbackManager.currentQueue
    val playbackMode: StateFlow<PlaybackMode> = playbackManager.playbackMode
    val playbackSpeed: StateFlow<Float> = playbackManager.playbackSpeed
    val bassBoostStrength: StateFlow<Int> = playbackManager.bassBoostStrength
    val sleepTimerLeft: StateFlow<Long> = playbackManager.sleepTimerMsLeft
    val lyricLine: StateFlow<String> = playbackManager.currentSyncedLyricLine

    // Search and Screen States
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    val searchedSongs: StateFlow<List<Song>> = combine(allSongs, _searchQuery) { songs, query ->
        if (query.isBlank()) songs
        else songs.filter { 
            it.title.contains(query, ignoreCase = true) || 
            it.artist.contains(query, ignoreCase = true) ||
            it.album.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Automatically scan and seed if repository is completely empty
        viewModelScope.launch {
            allSongs.collect { songs ->
                if (songs.isEmpty()) {
                    scanAndSaveDeviceSongs(SonicPlayerApplication.instance.applicationContext)
                }
            }
        }
    }

    // Media Scanning triggers
    fun scanAndSaveDeviceSongs(context: Context) {
        viewModelScope.launch {
            val songs = MediaStoreScanner.scanDeviceSongs(context)
            repository.insertSongs(songs)
        }
    }

    // Playback commands
    fun playSong(song: Song) {
        viewModelScope.launch {
            val list = allSongs.value.ifEmpty { listOf(song) }
            val index = list.indexOfFirst { it.id == song.id }.coerceAtLeast(0)
            playbackManager.setQueue(list, index)
            repository.addToRecentlyPlayed(song.id)
        }
    }

    fun playPlaylist(songs: List<Song>, startIndex: Int = 0) {
        if (songs.isEmpty()) return
        viewModelScope.launch {
            playbackManager.setQueue(songs, startIndex)
            repository.addToRecentlyPlayed(songs[startIndex].id)
        }
    }

    fun togglePlayPause() {
        playbackManager.togglePlayPause()
    }

    fun next() {
        playbackManager.next()
        val nextSong = playbackManager.currentSong.value
        if (nextSong != null) {
            viewModelScope.launch {
                repository.addToRecentlyPlayed(nextSong.id)
            }
        }
    }

    fun previous() {
        playbackManager.previous()
        val prevSong = playbackManager.currentSong.value
        if (prevSong != null) {
            viewModelScope.launch {
                repository.addToRecentlyPlayed(prevSong.id)
            }
        }
    }

    fun seekTo(positionMs: Long) {
        playbackManager.seekTo(positionMs)
    }

    fun setSpeed(speed: Float) {
        playbackManager.setSpeed(speed)
    }

    fun togglePlaybackMode() {
        playbackManager.togglePlaybackMode()
    }

    // Favorites
    fun toggleFavorite(song: Song) {
        viewModelScope.launch {
            repository.updateFavorite(song.id, !song.isFavorite)
        }
    }

    // Playlist Operations
    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name)
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
        }
    }

    fun addSongToPlaylist(playlistId: String, songId: String) {
        viewModelScope.launch {
            repository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun removeSongFromPlaylist(playlistId: String, songId: String) {
        viewModelScope.launch {
            repository.removeSongFromPlaylist(playlistId, songId)
        }
    }

    fun getSongsForPlaylist(playlistId: String): Flow<List<Song>> {
        return repository.getSongsForPlaylist(playlistId)
    }

    // Sleep Timer
    fun startSleepTimer(minutes: Int) {
        playbackManager.startSleepTimer(minutes)
    }

    fun stopSleepTimer() {
        playbackManager.stopSleepTimer()
    }

    // EQ bands and levels
    fun setBassBoost(strength: Int) {
        playbackManager.setBassBoost(strength)
    }

    fun setBandLevel(band: Int, level: Short) {
        playbackManager.setEqBandLevel(band, level)
    }

    fun getEqBands(): List<String> {
        return playbackManager.getEqBands()
    }

    fun getBandLevelRange(): IntArray {
        return playbackManager.getBandLevelRange()
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun getAudioSessionId(): Int = playbackManager.getAudioSessionId()
}
