package com.example.ui.screens

import android.content.Context
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.Album
import com.example.domain.model.Artist
import com.example.domain.model.Playlist
import com.example.domain.model.Song
import com.example.visualizer.*
import com.example.service.PlaybackMode
import com.example.ui.theme.SonicThemeType
import com.example.ui.viewmodel.MusicViewModel

// Screen and Tab navigation routing
enum class ScreenState {
    SPLASH, WELCOME, PERMISSION, MAIN
}

enum class HomeTab {
    HOME, SEARCH, LIBRARY, PLAYLISTS, SETTINGS
}

enum class SubScreen {
    NONE, ALBUM_DETAIL, ARTIST_DETAIL, PLAYLIST_DETAIL, FAVORITES, RECENTLY_PLAYED, ABOUT, EQUALIZER, SLEEP_TIMER, VISUALIZER_SETTINGS
}

@Composable
fun SonicMasterLayout(
    viewModel: MusicViewModel,
    themeTypeState: MutableState<SonicThemeType>,
    modifier: Modifier = Modifier
) {
    val visualizerViewModel: VisualizerViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    var screenState by remember { mutableStateOf(ScreenState.SPLASH) }
    var currentTab by remember { mutableStateOf(HomeTab.HOME) }
    var activeSubScreen by remember { mutableStateOf(SubScreen.NONE) }
    
    // Drilldown details holder
    var selectedAlbum by remember { mutableStateOf<Album?>(null) }
    var selectedArtist by remember { mutableStateOf<Artist?>(null) }
    var selectedPlaylist by remember { mutableStateOf<Playlist?>(null) }
    
    // Full screen player expandable panel state
    var showPlayerFullScreen by remember { mutableStateOf(false) }

    // Splash effect timer
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(2000)
        screenState = ScreenState.WELCOME
    }

    when (screenState) {
        ScreenState.SPLASH -> {
            SplashScreenLayout()
        }
        ScreenState.WELCOME -> {
            WelcomeScreenLayout {
                screenState = ScreenState.PERMISSION
            }
        }
        ScreenState.PERMISSION -> {
            PermissionScreenLayout {
                screenState = ScreenState.MAIN
            }
        }
        ScreenState.MAIN -> {
            val snackbarHostState = remember { SnackbarHostState() }
            
            Scaffold(
                snackbarHost = { SnackbarHost(snackbarHostState) },
                bottomBar = {
                    Column {
                        // 1. Persistent Mini Player above Navigation Bar
                        MiniPlayerSection(viewModel) {
                            showPlayerFullScreen = true
                        }
                        
                        // 2. M3 Bottom Navigation Bar
                        NavigationBar(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                            tonalElevation = 8.dp,
                            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                        ) {
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home", fontSize = 11.sp) },
                                selected = currentTab == HomeTab.HOME && activeSubScreen == SubScreen.NONE,
                                onClick = {
                                    currentTab = HomeTab.HOME
                                    activeSubScreen = SubScreen.NONE
                                },
                                modifier = Modifier.testTag("nav_home_tab")
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                                label = { Text("Search", fontSize = 11.sp) },
                                selected = currentTab == HomeTab.SEARCH && activeSubScreen == SubScreen.NONE,
                                onClick = {
                                    currentTab = HomeTab.SEARCH
                                    activeSubScreen = SubScreen.NONE
                                },
                                modifier = Modifier.testTag("nav_search_tab")
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.LibraryMusic, contentDescription = "Library") },
                                label = { Text("Library", fontSize = 11.sp) },
                                selected = currentTab == HomeTab.LIBRARY && activeSubScreen == SubScreen.NONE,
                                onClick = {
                                    currentTab = HomeTab.LIBRARY
                                    activeSubScreen = SubScreen.NONE
                                },
                                modifier = Modifier.testTag("nav_library_tab")
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.PlaylistPlay, contentDescription = "Playlists") },
                                label = { Text("Playlists", fontSize = 11.sp) },
                                selected = currentTab == HomeTab.PLAYLISTS && activeSubScreen == SubScreen.NONE,
                                onClick = {
                                    currentTab = HomeTab.PLAYLISTS
                                    activeSubScreen = SubScreen.NONE
                                },
                                modifier = Modifier.testTag("nav_playlists_tab")
                            )
                            NavigationBarItem(
                                icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                label = { Text("Settings", fontSize = 11.sp) },
                                selected = currentTab == HomeTab.SETTINGS && activeSubScreen == SubScreen.NONE,
                                onClick = {
                                    currentTab = HomeTab.SETTINGS
                                    activeSubScreen = SubScreen.NONE
                                },
                                modifier = Modifier.testTag("nav_settings_tab")
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.background,
                                    MaterialTheme.colorScheme.background.copy(alpha = 0.9f)
                                )
                            )
                        )
                ) {
                    if (activeSubScreen != SubScreen.NONE) {
                        // Sub-screens Drilldowns
                        when (activeSubScreen) {
                            SubScreen.ALBUM_DETAIL -> {
                                AlbumDetailLayout(selectedAlbum, viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.ARTIST_DETAIL -> {
                                ArtistDetailLayout(selectedArtist, viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.PLAYLIST_DETAIL -> {
                                PlaylistDetailLayout(selectedPlaylist, viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.FAVORITES -> {
                                FavoritesLayout(viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.RECENTLY_PLAYED -> {
                                RecentlyPlayedLayout(viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.ABOUT -> {
                                AboutLayout {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.EQUALIZER -> {
                                EqualizerLayout(viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.SLEEP_TIMER -> {
                                SleepTimerLayout(viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            SubScreen.VISUALIZER_SETTINGS -> {
                                VisualizerSettingsLayout(visualizerViewModel, viewModel) {
                                    activeSubScreen = SubScreen.NONE
                                }
                            }
                            else -> {}
                        }
                    } else {
                        // Core Tabs
                        when (currentTab) {
                            HomeTab.HOME -> {
                                HomeScreenLayout(
                                    viewModel = viewModel,
                                    onFavoritesClick = { activeSubScreen = SubScreen.FAVORITES },
                                    onRecentlyPlayedClick = { activeSubScreen = SubScreen.RECENTLY_PLAYED }
                                )
                            }
                            HomeTab.SEARCH -> {
                                SearchScreenLayout(viewModel)
                            }
                            HomeTab.LIBRARY -> {
                                LibraryScreenLayout(
                                    viewModel = viewModel,
                                    onAlbumClick = {
                                        selectedAlbum = it
                                        activeSubScreen = SubScreen.ALBUM_DETAIL
                                    },
                                    onArtistClick = {
                                        selectedArtist = it
                                        activeSubScreen = SubScreen.ARTIST_DETAIL
                                    }
                                )
                            }
                            HomeTab.PLAYLISTS -> {
                                PlaylistScreenLayout(
                                    viewModel = viewModel,
                                    onPlaylistClick = {
                                        selectedPlaylist = it
                                        activeSubScreen = SubScreen.PLAYLIST_DETAIL
                                    }
                                )
                            }
                            HomeTab.SETTINGS -> {
                                SettingsScreenLayout(
                                    onAboutClick = { activeSubScreen = SubScreen.ABOUT },
                                    onEqualizerClick = { activeSubScreen = SubScreen.EQUALIZER },
                                    onSleepTimerClick = { activeSubScreen = SubScreen.SLEEP_TIMER },
                                    onVisualizerClick = { activeSubScreen = SubScreen.VISUALIZER_SETTINGS },
                                    themeTypeState = themeTypeState
                                )
                            }
                        }
                    }

                    // Sliding Expandable Full Screen Player
                    AnimatedVisibility(
                        visible = showPlayerFullScreen,
                        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        FullPlayerLayout(
                            viewModel = viewModel,
                            visualizerViewModel = visualizerViewModel,
                            onClose = { showPlayerFullScreen = false }
                        )
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 1. SPLASH SCREEN
// ═══════════════════════════════════════
@Composable
fun SplashScreenLayout() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B19)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Rotating pulse visual circle
            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
            val scale by infiniteTransition.animateFloat(
                initialValue = 0.85f,
                targetValue = 1.15f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "scale"
            )

            Box(
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Color(0xFF00F5FF).copy(alpha = 0.4f), Color.Transparent)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MusicNote,
                    contentDescription = "Sonic Wave Logo",
                    tint = Color(0xFF00F5FF),
                    modifier = Modifier
                        .size(64.dp)
                        .scale(scale)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "SONIC PLAYER",
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                letterSpacing = 4.sp,
                color = Color.White
            )

            Text(
                text = "Supreme Audio Station",
                fontSize = 13.sp,
                letterSpacing = 2.sp,
                color = Color(0xFF00D2FF).copy(alpha = 0.8f)
            )

            Spacer(modifier = Modifier.height(60.dp))

            Text(
                text = "Developed by Mr Sadek World",
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.6f)
            )
            
            Text(
                text = "© Mr Sadek World",
                fontSize = 10.sp,
                color = Color.White.copy(alpha = 0.4f)
            )
        }
    }
}

// ═══════════════════════════════════════
// 2. WELCOME SCREEN
// ═══════════════════════════════════════
@Composable
fun WelcomeScreenLayout(onNext: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B19))
            .padding(24.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.weight(1f))

            Icon(
                imageVector = Icons.Default.Headset,
                contentDescription = null,
                tint = Color(0xFF00F5FF),
                modifier = Modifier.size(80.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Welcome to Sonic",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 32.sp,
                textAlign = TextAlign.Center,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Engage with commercial-grade audio presets, seamless folders, sliding synced lyrics, and high fidelity playback engine designed for real music connoisseurs.",
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                color = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.weight(1.2f))

            Button(
                onClick = onNext,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F5FF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("welcome_next_button")
            ) {
                Text(
                    text = "GET STARTED",
                    color = Color(0xFF070B19),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Developed by Mr Sadek World",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.5f)
            )
        }
    }
}

// ═══════════════════════════════════════
// 3. PERMISSION SCREEN
// ═══════════════════════════════════════
@Composable
fun PermissionScreenLayout(onNext: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070B19))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.FolderOpen,
                contentDescription = null,
                tint = Color(0xFF00D2FF),
                modifier = Modifier.size(72.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Library Access Required",
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Sonic Player needs permissions to scan your local storage for songs, folders, and artists. If none are stored, premium streams will be loaded.",
                fontSize = 14.sp,
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onNext,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2FF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("grant_permission_button")
            ) {
                Text(
                    text = "GRANT PERMISSION",
                    color = Color(0xFF070B19),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ═══════════════════════════════════════
// 4. HOME SCREEN
// ═══════════════════════════════════════
@Composable
fun HomeScreenLayout(
    viewModel: MusicViewModel,
    onFavoritesClick: () -> Unit,
    onRecentlyPlayedClick: () -> Unit
) {
    val songs by viewModel.allSongs.collectAsState()
    val recentSongs by viewModel.recentlyPlayed.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Welcome Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Hello music fan",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                    Text(
                        text = "Sonic Music",
                        fontWeight = FontWeight.Black,
                        fontSize = 28.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                
                IconButton(
                    onClick = onFavoritesClick,
                    modifier = Modifier.testTag("home_fav_shortcut")
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Favorite",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }

        // Shortcut Quick Panel
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Favorites Card
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                        .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                        .clickable { onFavoritesClick() }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = null,
                        tint = Color.Red,
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Favorites", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                }

                // Recent Card
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                        .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                        .clickable { onRecentlyPlayedClick() }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Recents", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                }
            }
        }

        // Recent Tracks Carousel
        if (recentSongs.isNotEmpty()) {
            item {
                Text(
                    text = "Recently Played",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(recentSongs) { song ->
                        Column(
                            modifier = Modifier
                                .width(120.dp)
                                .clickable { viewModel.playSong(song) }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Gray.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.LibraryMusic, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = song.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = song.artist,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
            }
        }

        // Dynamic Tracks List
        item {
            Text(
                text = "All Available Songs",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        if (songs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No local tracks found. Scanning...", color = Color.Gray)
                }
            }
        } else {
            items(songs) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.playSong(song) }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(song.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(song.artist, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
                    }
                    IconButton(onClick = { viewModel.toggleFavorite(song) }) {
                        Icon(
                            imageVector = if (song.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Toggle Favorite",
                            tint = if (song.isFavorite) Color.Red else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
                        )
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 5. SEARCH SCREEN
// ═══════════════════════════════════════
@Composable
fun SearchScreenLayout(viewModel: MusicViewModel) {
    val query by viewModel.searchQuery.collectAsState()
    val results by viewModel.searchedSongs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = { viewModel.updateSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_text_input"),
            placeholder = { Text("Search songs, folders, album arts...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            shape = RoundedCornerShape(16.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (results.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Search yields no tracks right now", color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(results) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playSong(song) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(song.title, fontWeight = FontWeight.Bold)
                            Text(song.artist, fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 6. LIBRARY SCREEN
// ═══════════════════════════════════════
@Composable
fun LibraryScreenLayout(
    viewModel: MusicViewModel,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit
) {
    val albums by viewModel.albums.collectAsState()
    val artists by viewModel.artists.collectAsState()
    var selectedIndex by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        TabRow(selectedTabIndex = selectedIndex, containerColor = Color.Transparent) {
            Tab(selected = selectedIndex == 0, onClick = { selectedIndex = 0 }) {
                Text("Albums", modifier = Modifier.padding(12.dp))
            }
            Tab(selected = selectedIndex == 1, onClick = { selectedIndex = 1 }) {
                Text("Artists", modifier = Modifier.padding(12.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedIndex) {
            0 -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(albums) { album ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onAlbumClick(album) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Album, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(album.title, fontWeight = FontWeight.Bold)
                                Text("${album.artist} • ${album.trackCount} Tracks", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
            1 -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(artists) { artist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onArtistClick(artist) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(artist.name, fontWeight = FontWeight.Bold)
                                Text("${artist.trackCount} Songs", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 7. ALBUM DRILLDOWN SCREEN
// ═══════════════════════════════════════
@Composable
fun AlbumDetailLayout(album: Album?, viewModel: MusicViewModel, onBack: () -> Unit) {
    val songs by viewModel.allSongs.collectAsState()
    val albumSongs = songs.filter { it.album == album?.title }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(8.dp))
            Text("Album Details", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(album?.title ?: "Unknown Album", fontWeight = FontWeight.Black, fontSize = 24.sp)
        Text(album?.artist ?: "Unknown Artist", fontSize = 13.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(albumSongs) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.playSong(song) }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.MusicNote, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(song.title, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 8. ARTIST DRILLDOWN SCREEN
// ═══════════════════════════════════════
@Composable
fun ArtistDetailLayout(artist: Artist?, viewModel: MusicViewModel, onBack: () -> Unit) {
    val songs by viewModel.allSongs.collectAsState()
    val artistSongs = songs.filter { it.artist == artist?.name }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(8.dp))
            Text("Artist Details", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(artist?.name ?: "Unknown Artist", fontWeight = FontWeight.Black, fontSize = 24.sp)
        Text("${artistSongs.size} Songs available", fontSize = 13.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(artistSongs) { song ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.playSong(song) }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.MusicNote, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(song.title, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 9. PLAYLIST SCREEN & DRILLDOWN
// ═══════════════════════════════════════
@Composable
fun PlaylistScreenLayout(viewModel: MusicViewModel, onPlaylistClick: (Playlist) -> Unit) {
    val playlists by viewModel.playlists.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Playlists", fontWeight = FontWeight.Bold, fontSize = 22.sp)
            IconButton(
                onClick = { showCreateDialog = true },
                modifier = Modifier.testTag("create_playlist_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Playlist")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (playlists.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Create new playlists to categorize tracks", color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(playlists) { list ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPlaylistClick(list) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PlaylistPlay, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(list.name, fontWeight = FontWeight.Bold)
                            Text("Click to view songs", fontSize = 11.sp, color = Color.Gray)
                        }
                        IconButton(onClick = { viewModel.deletePlaylist(list.id) }) {
                            Icon(Icons.Default.Delete, tint = Color.Red.copy(alpha = 0.5f), contentDescription = "Delete")
                        }
                    }
                }
            }
        }

        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                title = { Text("Create Playlist") },
                text = {
                    OutlinedTextField(
                        value = newPlaylistName,
                        onValueChange = { newPlaylistName = it },
                        placeholder = { Text("Enter playlist title") }
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        if (newPlaylistName.isNotBlank()) {
                            viewModel.createPlaylist(newPlaylistName)
                            newPlaylistName = ""
                            showCreateDialog = false
                        }
                    }) { Text("Create") }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
fun PlaylistDetailLayout(playlist: Playlist?, viewModel: MusicViewModel, onBack: () -> Unit) {
    var pSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    
    LaunchedEffect(playlist) {
        if (playlist != null) {
            viewModel.getSongsForPlaylist(playlist.id).collect {
                pSongs = it
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(8.dp))
            Text("Playlist Detail", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(playlist?.name ?: "Unnamed Playlist", fontWeight = FontWeight.Black, fontSize = 24.sp)
        Text("${pSongs.size} Songs loaded", fontSize = 12.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(20.dp))

        if (pSongs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("This playlist has no songs yet", color = Color.Gray)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(pSongs) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playSong(song) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MusicNote, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(song.title, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 10. PERSISTENT MINI PLAYER
// ═══════════════════════════════════════
@Composable
fun MiniPlayerSection(viewModel: MusicViewModel, onClick: () -> Unit) {
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val position by viewModel.currentPosition.collectAsState()
    val playbackMode by viewModel.playbackMode.collectAsState()

    if (currentSong != null) {
        val infiniteTransition = rememberInfiniteTransition(label = "mini_vinyl")
        val rotationAngle by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(8000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "mini_rotation"
        )

        val duration = currentSong?.duration ?: 1L
        val progress = if (duration > 0L) position.toFloat() / duration.toFloat() else 0f

        // Glassmorphic floating control card structure
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF0F172A).copy(alpha = 0.65f)) // Translucent core layer
                .border(
                    width = 1.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.18f),
                            Color.White.copy(alpha = 0.03f)
                        )
                    ),
                    shape = RoundedCornerShape(22.dp)
                )
                .clickable { onClick() }
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // High-precision integrated linear progress seek line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .background(Color.White.copy(alpha = 0.08f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .fillMaxWidth(progress.coerceIn(0f, 1f))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color(0xFF00F5FF), Color(0xFF00FF87))
                                )
                            )
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Modern Vinyl disk cover simulation
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape)
                            .rotate(if (isPlaying) rotationAngle else 0f),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = Color(0xFF00F5FF),
                            modifier = Modifier.size(24.dp)
                        )
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(
                                color = Color.White.copy(alpha = 0.08f),
                                radius = size.minDimension / 2.5f,
                                style = Stroke(width = 1.dp.toPx())
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    // Track details: auto squishing prevention and elegant text spacing
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentSong!!.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = currentSong!!.artist,
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.62f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Media Controls using direct Media3 session state bindings
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Playback Mode Switcher (Repeat All, Repeat One, Shuffle)
                        IconButton(
                            onClick = { viewModel.togglePlaybackMode() },
                            modifier = Modifier.size(34.dp)
                        ) {
                            val modeIcon = when (playbackMode) {
                                PlaybackMode.REPEAT_ALL -> Icons.Default.Repeat
                                PlaybackMode.REPEAT_ONE -> Icons.Default.RepeatOne
                                PlaybackMode.SHUFFLE -> Icons.Default.Shuffle
                            }
                            val modeColor = when (playbackMode) {
                                PlaybackMode.REPEAT_ALL -> Color(0xFF00F5FF)
                                PlaybackMode.REPEAT_ONE -> Color(0xFF00FF87)
                                PlaybackMode.SHUFFLE -> Color(0xFFFF007F)
                            }
                            Icon(
                                imageVector = modeIcon,
                                contentDescription = "Playback Mode Toggle",
                                tint = modeColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Skip Previous
                        IconButton(
                            onClick = { viewModel.previous() },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipPrevious,
                                contentDescription = "Previous Song",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Play / Pause Toggle Circle
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00F5FF).copy(alpha = 0.15f))
                                .border(1.5.dp, Color(0xFF00F5FF), CircleShape)
                                .clickable { viewModel.togglePlayPause() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color(0xFF00F5FF),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Skip Next
                        IconButton(
                            onClick = { viewModel.next() },
                            modifier = Modifier.size(34.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.SkipNext,
                                contentDescription = "Next Song",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 11. FULL SCREEN PLAYER LAYOUT (Glassmorphic)
// ═══════════════════════════════════════
@Composable
fun FullPlayerLayout(
    viewModel: MusicViewModel,
    visualizerViewModel: VisualizerViewModel,
    onClose: () -> Unit
) {
    val currentSong by viewModel.currentSong.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val position by viewModel.currentPosition.collectAsState()
    val playbackSpeed by viewModel.playbackSpeed.collectAsState()
    val mode by viewModel.playbackMode.collectAsState()
    val lyricsLine by viewModel.lyricLine.collectAsState()

    var showLyricsView by remember { mutableStateOf(false) }

    val visualizerEnabled by visualizerViewModel.isEnabled.collectAsState()
    val activeType by visualizerViewModel.visualizerType.collectAsState()
    val fft by visualizerViewModel.rawFFT.collectAsState()
    val waveform by visualizerViewModel.rawWaveform.collectAsState()
    val beat by visualizerViewModel.beatDetected.collectAsState()
    val bass by visualizerViewModel.bassValue.collectAsState()
    val treble by visualizerViewModel.trebleValue.collectAsState()
    val preset by visualizerViewModel.colorPreset.collectAsState()
    val barW by visualizerViewModel.barWidthDp.collectAsState()
    val barS by visualizerViewModel.barSpacingDp.collectAsState()

    LaunchedEffect(isPlaying, position) {
        if (isPlaying) {
            while (true) {
                visualizerViewModel.tick(isPlaying = true, progressMs = position)
                kotlinx.coroutines.delay(16)
            }
        } else {
            visualizerViewModel.tick(isPlaying = false, progressMs = position)
        }
    }

    val sessionId = viewModel.getAudioSessionId()
    LaunchedEffect(sessionId) {
        if (sessionId != 0) {
            visualizerViewModel.updateSessionId(sessionId)
        }
    }

    if (currentSong != null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF070B19))
                .padding(24.dp)
        ) {
            if (visualizerEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .alpha(if (activeType == VisualizerType.AMBIENT_GLOW) 0.65f else 0.35f)
                ) {
                    when (activeType) {
                        VisualizerType.SPECTRUM_NARROW -> {
                            SpectrumNarrowVisualizer(
                                fftData = fft,
                                colorPreset = preset,
                                barWidthDp = barW,
                                barSpacingDp = barS,
                                isWide = false,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        VisualizerType.SPECTRUM_WIDE -> {
                            SpectrumNarrowVisualizer(
                                fftData = fft,
                                colorPreset = preset,
                                barWidthDp = barW,
                                barSpacingDp = barS,
                                isWide = true,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        VisualizerType.WAVEFORM -> {
                            WaveformVisualizer(
                                waveform = waveform,
                                colorPreset = preset,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        VisualizerType.PARTICLE -> {
                            ParticleVisualizer(
                                beatDetected = beat,
                                bassValue = bass,
                                colorPreset = preset,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        VisualizerType.AMBIENT_GLOW -> {
                            AmbientGlowVisualizer(
                                beatDetected = beat,
                                bassValue = bass,
                                colorPreset = preset,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        else -> {}
                    }
                }
            }

            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onClose) {
                        Icon(imageVector = Icons.Default.KeyboardArrowDown, tint = Color.White, contentDescription = "Collapse")
                    }
                    Text(
                        text = "NOW PLAYING",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 2.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                    IconButton(onClick = { showLyricsView = !showLyricsView }) {
                        Icon(
                            imageVector = Icons.Default.Notes,
                            tint = if (showLyricsView) Color(0xFF00F5FF) else Color.White,
                            contentDescription = "Lyrics"
                        )
                    }
                }

                if (showLyricsView) {
                    SyncedLyricsViewContent(currentSong!!, position)
                } else {
                    val rotation = rememberInfiniteTransition(label = "vinyl")
                    val angle by rotation.animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(12000, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "rotation"
                    )

                    Box(
                        modifier = Modifier.size(310.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (visualizerEnabled && activeType == VisualizerType.CIRCULAR) {
                            CircularVisualizer(
                                fftData = fft,
                                colorPreset = preset,
                                modifier = Modifier.matchParentSize()
                            )
                        }

                        Box(
                            modifier = Modifier
                                .size(240.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF0A1128))
                                .border(6.dp, Color(0xFF1E293B), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(220.dp)
                                    .rotate(if (isPlaying) angle else 0f)
                                    .clip(CircleShape)
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    drawCircle(
                                        color = Color(0xFF00F5FF).copy(alpha = 0.15f),
                                        radius = size.minDimension / 2.3f,
                                        style = Stroke(width = 1.dp.toPx())
                                    )
                                    drawCircle(
                                        color = Color(0xFF00F5FF).copy(alpha = 0.05f),
                                        radius = size.minDimension / 3.5f,
                                        style = Stroke(width = 1.dp.toPx())
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.MusicNote,
                                    contentDescription = null,
                                    tint = Color(0xFF00F5FF),
                                    modifier = Modifier.size(72.dp)
                                )
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = lyricsLine.ifEmpty { "[No scrolling lyrics synced]" },
                            color = if (lyricsLine.isNotEmpty()) Color(0xFF00F5FF) else Color.White.copy(alpha = 0.4f),
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Metadata Details
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = currentSong!!.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = currentSong!!.artist,
                        fontSize = 14.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                }

                // Interactive progress slider
                Column(modifier = Modifier.fillMaxWidth()) {
                    val duration = currentSong!!.duration
                    val sliderVal = position.coerceAtMost(duration).toFloat()

                    Slider(
                        value = sliderVal,
                        onValueChange = { viewModel.seekTo(it.toLong()) },
                        valueRange = 0f..duration.toFloat(),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00F5FF),
                            activeTrackColor = Color(0xFF00F5FF),
                            inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatMs(position), fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                        Text(formatMs(duration), fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                    }
                }

                // Control Triggers Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Playback speed switch
                    TextButton(
                        onClick = {
                            val nextSpeed = when (playbackSpeed) {
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 2.0f
                                2.0f -> 0.75f
                                else -> 1.0f
                            }
                            viewModel.setSpeed(nextSpeed)
                        }
                    ) {
                        Text("${playbackSpeed}x", color = Color(0xFF00F5FF), fontWeight = FontWeight.Bold)
                    }

                    IconButton(onClick = { viewModel.previous() }) {
                        Icon(imageVector = Icons.Default.SkipPrevious, contentDescription = "Previous Song", tint = Color.White, modifier = Modifier.size(36.dp))
                    }

                    // Floating Round Button
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00F5FF))
                            .clickable { viewModel.togglePlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause Toggle",
                            tint = Color(0xFF070B19),
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    IconButton(onClick = { viewModel.next() }) {
                        Icon(imageVector = Icons.Default.SkipNext, contentDescription = "Next Song", tint = Color.White, modifier = Modifier.size(36.dp))
                    }

                    // Mode Toggle (Shuffle/Repeat)
                    IconButton(onClick = { viewModel.togglePlaybackMode() }) {
                        val icon = when (mode) {
                            PlaybackMode.REPEAT_ALL -> Icons.Default.Repeat
                            PlaybackMode.REPEAT_ONE -> Icons.Default.RepeatOne
                            PlaybackMode.SHUFFLE -> Icons.Default.Shuffle
                        }
                        Icon(imageVector = icon, contentDescription = "Playback Mode Toggle", tint = Color(0xFF00F5FF))
                    }
                }

                // Dev Credits on bottom
                Text(
                    text = "Acoustic Station by Mr Sadek World",
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.4f),
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

// Synced lyrics screen
@Composable
fun SyncedLyricsViewContent(song: Song, activePos: Long) {
    if (song.syncedLyrics.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("No synced lyrics found for this item.", color = Color.Gray)
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(song.syncedLyrics) { line ->
                val isActive = activePos >= line.timeMs && 
                        (song.syncedLyrics.getOrNull(song.syncedLyrics.indexOf(line) + 1)?.timeMs ?: Long.MAX_VALUE) > activePos

                Text(
                    text = line.text,
                    color = if (isActive) Color(0xFF00F5FF) else Color.White.copy(alpha = 0.5f),
                    fontSize = if (isActive) 18.sp else 14.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// Helper time formatter
fun formatMs(ms: Long): String {
    val sec = (ms / 1000) % 60
    val min = (ms / (1000 * 60)) % 60
    return String.format("%02d:%02d", min, sec)
}

// ═══════════════════════════════════════
// 12. FAVORITES LAYOUT
// ═══════════════════════════════════════
@Composable
fun FavoritesLayout(viewModel: MusicViewModel, onBack: () -> Unit) {
    val favoriteSongs by viewModel.favoriteSongs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(10.dp))
            Text("Favorites Storage", fontWeight = FontWeight.Black, fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (favoriteSongs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Click the heart icon on songs to add them here", color = Color.Gray, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(favoriteSongs) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playSong(song) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MusicNote, tint = Color.Red, contentDescription = null)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, fontWeight = FontWeight.Bold)
                            Text(song.artist, fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 13. RECENTLY PLAYED LAYOUT
// ═══════════════════════════════════════
@Composable
fun RecentlyPlayedLayout(viewModel: MusicViewModel, onBack: () -> Unit) {
    val recentSongs by viewModel.recentlyPlayed.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(10.dp))
            Text("Recently Played", fontWeight = FontWeight.Black, fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (recentSongs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Play tracks from libraries to see them listed here", color = Color.Gray, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(recentSongs) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.playSong(song) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.History, tint = MaterialTheme.colorScheme.primary, contentDescription = null)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, fontWeight = FontWeight.Bold)
                            Text(song.artist, fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 14. SETTINGS TAB SCREEN
// ═══════════════════════════════════════
@Composable
fun SettingsScreenLayout(
    onAboutClick: () -> Unit,
    onEqualizerClick: () -> Unit,
    onSleepTimerClick: () -> Unit,
    onVisualizerClick: () -> Unit,
    themeTypeState: MutableState<SonicThemeType>
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Sonic Preferences", fontWeight = FontWeight.Black, fontSize = 24.sp)

        // 1. Theme selection settings
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Theme Style", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { themeTypeState.value = SonicThemeType.DARK },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (themeTypeState.value == SonicThemeType.DARK) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f)
                        )
                    ) { Text("Dark Navy") }

                    Button(
                        onClick = { themeTypeState.value = SonicThemeType.AMOLED },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (themeTypeState.value == SonicThemeType.AMOLED) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f)
                        )
                    ) { Text("AMOLED") }

                    Button(
                        onClick = { themeTypeState.value = SonicThemeType.LIGHT },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (themeTypeState.value == SonicThemeType.LIGHT) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f)
                        )
                    ) { Text("Light") }
                }
            }
        }

        // 2. Audio Effects settings shortcut
        ListItem(
            headlineContent = { Text("Equalizer & Presets", fontWeight = FontWeight.Bold) },
            supportingContent = { Text("Adjust 5-Bands and Bass Boost strengths", fontSize = 12.sp) },
            leadingContent = { Icon(Icons.Default.Tune, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            modifier = Modifier
                .clickable { onEqualizerClick() }
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
        )

        // 3. Audio Visualizer settings shortcut
        ListItem(
            headlineContent = { Text("HD Audio Visualizer", fontWeight = FontWeight.Bold) },
            supportingContent = { Text("Customize spectrum, circular, & waveform visualizer rendering", fontSize = 12.sp) },
            leadingContent = { Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color(0xFF00F5FF)) },
            modifier = Modifier
                .clickable { onVisualizerClick() }
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                .testTag("visualizer_settings_item")
        )

        // 4. Sleep settings shortcut
        ListItem(
            headlineContent = { Text("Sleep Timer", fontWeight = FontWeight.Bold) },
            supportingContent = { Text("Set a countdown to stop active streams", fontSize = 12.sp) },
            leadingContent = { Icon(Icons.Default.HourglassEmpty, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            modifier = Modifier
                .clickable { onSleepTimerClick() }
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
        )

        // 4. About screen shortcuts
        ListItem(
            headlineContent = { Text("Sonic Information & About", fontWeight = FontWeight.Bold) },
            supportingContent = { Text("App version, Developer copyright, Licences", fontSize = 12.sp) },
            leadingContent = { Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            modifier = Modifier
                .clickable { onAboutClick() }
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
        )

        Spacer(modifier = Modifier.weight(1f))

        Text(
            text = "Developed by Mr Sadek World",
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            color = Color.LightGray.copy(alpha = 0.4f),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

// ═══════════════════════════════════════
// 15. EQUALIZER LEVEL CONFIG LAYOUT
// ═══════════════════════════════════════
@Composable
fun EqualizerLayout(viewModel: MusicViewModel, onBack: () -> Unit) {
    val bassBoostStrength by viewModel.bassBoostStrength.collectAsState()
    val bands = viewModel.getEqBands()
    val range = viewModel.getBandLevelRange()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(10.dp))
            Text("Hardware Equalizer", fontWeight = FontWeight.Black, fontSize = 20.sp)
        }

        // Bass Booster section dial
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("BASS BOOSTER DENSITY", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Slider(
                    value = bassBoostStrength.toFloat(),
                    onValueChange = { viewModel.setBassBoost(it.toInt()) },
                    valueRange = 0f..1000f,
                    colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary)
                )
                Text("Active Gain: ${bassBoostStrength / 10}%", fontSize = 11.sp, color = Color.Gray)
            }
        }

        // 5-Bands sections
        Text("MULTI-PRESET BANDS", fontWeight = FontWeight.Bold, fontSize = 13.sp)

        Card(
            modifier = Modifier.fillMaxWidth().weight(1f),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.4f))
        ) {
            LazyColumn(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(bands.size) { index ->
                    val settingsRepository = remember { com.example.SonicPlayerApplication.instance.settingsRepository }
                    val savedLevelState = settingsRepository.eqBandFlow(index).collectAsState(initial = 0)
                    
                    // Convert level in range [range[0] .. range[1]] to float [0f .. 1f]
                    val initialGain = remember(savedLevelState.value) {
                        val maxVal = range[1].toFloat()
                        val minVal = range[0].toFloat()
                        if (maxVal > minVal) {
                            ((savedLevelState.value - minVal) / (maxVal - minVal)).coerceIn(0f, 1f)
                        } else {
                            0.5f
                        }
                    }
                    var itemGain by remember(initialGain) { mutableStateOf(initialGain) }

                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "${bands[index]} Band", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                            val gainDb = (itemGain * (range[1] - range[0]) + range[0]) / 100f
                            Text(text = "${String.format("%.1f", gainDb)} dB", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = itemGain,
                            onValueChange = {
                                itemGain = it
                                val step = (it * (range[1] - range[0]) + range[0]).toInt().toShort()
                                viewModel.setBandLevel(index, step)
                            },
                            valueRange = 0f..1f
                        )
                    }
                }
            }
        }
    }
}

// ═══════════════════════════════════════
// 16. SLEEP TIMER DIALOG PAGE
// ═══════════════════════════════════════
@Composable
fun SleepTimerLayout(viewModel: MusicViewModel, onBack: () -> Unit) {
    val timeLeftRaw by viewModel.sleepTimerLeft.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
            Spacer(modifier = Modifier.width(10.dp))
            Text("Snooze Settings", fontWeight = FontWeight.Black, fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.height(30.dp))

        Box(
            modifier = Modifier
                .size(160.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.HourglassFull, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (timeLeftRaw > 0) formatMs(timeLeftRaw) else "Inactive",
                    fontWeight = FontWeight.Black,
                    fontSize = 24.sp
                )
            }
        }

        Text("Select sleep threshold to pause playing tracks automatically", textAlign = TextAlign.Center, color = Color.Gray)

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Button(onClick = { viewModel.startSleepTimer(10) }) { Text("10 Mins") }
            Button(onClick = { viewModel.startSleepTimer(30) }) { Text("30 Mins") }
            Button(onClick = { viewModel.startSleepTimer(60) }) { Text("60 Mins") }
        }

        TextButton(onClick = { viewModel.stopSleepTimer() }) {
            Text("CANCEL ACTIVE TIMER", color = Color.Red, fontWeight = FontWeight.Bold)
        }
    }
}

// ═══════════════════════════════════════
// 17. SPECIAL DESIGN OVERVIEW ABOUT PAGE
// ═══════════════════════════════════════
@Composable
fun AboutLayout(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                Spacer(modifier = Modifier.width(10.dp))
                Text("About Application", fontWeight = FontWeight.Black, fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.height(40.dp))

            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.radialGradient(colors = listOf(Color(0xFF00F5FF), Color(0xFF0284C7)))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.White)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("SONIC PLAYER", fontWeight = FontWeight.Black, fontSize = 24.sp, letterSpacing = 2.sp)
            Text("Version 1.0.0 (Ultimate Build)", fontSize = 12.sp, color = Color.Gray)

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Developer: Mr Sadek World", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Branding & Concepts: Mr Sadek World", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Licences: Licensed under Copyright © Mr Sadek World. All rights reserved.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Developed by Mr Sadek World", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color.Gray)
            Text("© Mr Sadek World", fontSize = 10.sp, color = Color.Gray.copy(alpha = 0.6f))
        }
    }
}

@Composable
fun VisualizerSettingsLayout(
    visualizerViewModel: VisualizerViewModel,
    viewModel: MusicViewModel,
    onBack: () -> Unit
) {
    val isEnabled by visualizerViewModel.isEnabled.collectAsState()
    val activeType by visualizerViewModel.visualizerType.collectAsState()
    val sensitivity by visualizerViewModel.sensitivity.collectAsState()
    val fpsLimit by visualizerViewModel.fpsLimit.collectAsState()
    val barWidth by visualizerViewModel.barWidthDp.collectAsState()
    val barSpacing by visualizerViewModel.barSpacingDp.collectAsState()
    val preset by visualizerViewModel.colorPreset.collectAsState()
    val useDynamicColors by visualizerViewModel.useDynamicAlbumColors.collectAsState()
    val quality by visualizerViewModel.quality.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(MaterialTheme.colorScheme.background)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("visualizer_settings_back_button")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "HD Audio Visualizer",
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                color = Color.White
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.35f)
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "Master Visualizer State",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                "Enable or disable audio analyzer loops",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                        Switch(
                            checked = isEnabled,
                            onCheckedChange = { visualizerViewModel.setEnabled(it) },
                            modifier = Modifier.testTag("visualizer_enable_switch")
                        )
                    }
                }
            }

            if (isEnabled) {
                item {
                    Text(
                        "Visualization Mode",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF00F5FF)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        VisualizerType.values().forEach { type ->
                            val isSelected = activeType == type
                            val descUrl = when (type) {
                                VisualizerType.SPECTRUM_NARROW -> "Precision thin multi-band spectrum analyser"
                                VisualizerType.SPECTRUM_WIDE -> "Thicker Poweramp-caliber logarithmic bands"
                                VisualizerType.WAVEFORM -> "Dynamic real-time audio oscilloscope line"
                                VisualizerType.CIRCULAR -> "Concentric radial frequency orbits around album art"
                                VisualizerType.PARTICLE -> "Floating gravity particles reactive to bass beats"
                                VisualizerType.AMBIENT_GLOW -> "Elegant background neon glow pulsing with music"
                            }
                            
                            ListItem(
                                headlineContent = { 
                                    Text(
                                        text = type.name.replace("_", " "), 
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) Color(0xFF00F5FF) else Color.White
                                    ) 
                                },
                                supportingContent = { Text(descUrl, fontSize = 11.sp, color = Color.Gray) },
                                leadingContent = { 
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = { visualizerViewModel.setVisualizerType(type) }
                                    ) 
                                },
                                modifier = Modifier
                                    .clickable { visualizerViewModel.setVisualizerType(type) }
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                        else MaterialTheme.colorScheme.surface.copy(alpha = 0.2f)
                                    )
                                    .testTag("type_${type.name.lowercase()}")
                            )
                        }
                    }
                }

                item {
                    Text(
                        "Color Theme Preset",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF00F5FF)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ColorPreset.values().forEach { colPreset ->
                            val isSelected = preset == colPreset
                            val colors = ColorPresetResolver.getColors(colPreset)
                            
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) Color.White.copy(alpha = 0.15f)
                                        else MaterialTheme.colorScheme.surface.copy(alpha = 0.2f)
                                    )
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) Color(0xFF00F5FF) else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { visualizerViewModel.setColorPreset(colPreset) }
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(colors.first))
                                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(colors.second))
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        colPreset.name.lowercase().replaceFirstChar { it.uppercase() },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected) Color(0xFF00F5FF) else Color.White
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.35f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Render Resolution & Performance", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Higher settings render at ultra HD but consume more battery", fontSize = 11.sp, color = Color.Gray)
                            
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                VisualizerQuality.values().forEach { q ->
                                    val isSelected = quality == q
                                    Button(
                                        onClick = { visualizerViewModel.setQuality(q) },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (isSelected) Color(0xFF00F5FF) else Color.Gray.copy(alpha = 0.15f),
                                            contentColor = if (isSelected) Color.Black else Color.White
                                        ),
                                        modifier = Modifier.testTag("quality_${q.name.lowercase()}")
                                    ) {
                                        Text(q.name.replace("_", " "), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text("Frame Rate Target (FPS)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                listOf(30, 60, 120).forEach { fps ->
                                    val isSelected = fpsLimit == fps
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (isSelected) Color(0xFF00F5FF).copy(alpha = 0.2f)
                                                else Color.Gray.copy(alpha = 0.1f)
                                            )
                                            .border(
                                                width = 1.dp,
                                                color = if (isSelected) Color(0xFF00F5FF) else Color.Transparent,
                                                shape = RoundedCornerShape(8.dp)
                                            )
                                            .clickable { visualizerViewModel.setFpsLimit(fps) }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("$fps FPS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isSelected) Color(0xFF00F5FF) else Color.White)
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.35f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Acoustic Physics & Tuning", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            
                            Spacer(modifier = Modifier.height(16.dp))
                            
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Spectrum Sensitivity", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("${String.format("%.1f", sensitivity)}x", fontSize = 12.sp, color = Color(0xFF00F5FF), fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = sensitivity,
                                onValueChange = { visualizerViewModel.setSensitivity(it) },
                                valueRange = 0.5f..2.5f,
                                colors = SliderDefaults.colors(
                                    thumbColor = Color(0xFF00F5FF),
                                    activeTrackColor = Color(0xFF00F5FF)
                                ),
                                modifier = Modifier.testTag("slider_sensitivity")
                            )

                            if (activeType == VisualizerType.SPECTRUM_NARROW || activeType == VisualizerType.SPECTRUM_WIDE) {
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Spectrum Bar Width", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${barWidth.toInt()} dp", fontSize = 12.sp, color = Color(0xFF00F5FF), fontWeight = FontWeight.Bold)
                                }
                                Slider(
                                    value = barWidth,
                                    onValueChange = { visualizerViewModel.setBarWidth(it) },
                                    valueRange = 1f..8f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFF00F5FF),
                                        activeTrackColor = Color(0xFF00F5FF)
                                    ),
                                    modifier = Modifier.testTag("slider_bar_width")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Bar Gap Spacing", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${barSpacing.toInt()} dp", fontSize = 12.sp, color = Color(0xFF00F5FF), fontWeight = FontWeight.Bold)
                                }
                                Slider(
                                    value = barSpacing,
                                    onValueChange = { visualizerViewModel.setBarSpacing(it) },
                                    valueRange = 1f..6f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = Color(0xFF00F5FF),
                                        activeTrackColor = Color(0xFF00F5FF)
                                    ),
                                    modifier = Modifier.testTag("slider_bar_spacing")
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

