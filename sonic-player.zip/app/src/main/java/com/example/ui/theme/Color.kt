package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Navy Blue Palette (For general dark / amoled themes)
val SonicDeepNavy = Color(0xFF070B19)
val SonicNavyMain = Color(0xFF0F172A)
val SonicNavyLight = Color(0xFF1E293B)
val SonicNavyMuted = Color(0xFF334155)

// Cyan Accents
val SonicCyanAccent = Color(0xFF00F5FF)
val SonicCyanBright = Color(0xFF00D2FF)
val SonicCyanMuted = Color(0xFF0284C7)

// Light Palette
val SonicLightBg = Color(0xFFF8FAFC)
val SonicLightSurface = Color(0xFFFFFFFF)
val SonicLightText = Color(0xFF0F172A)
val SonicLightMuted = Color(0xFF64748B)

// Secondary/Tertiaries
val SonicPurpleAccent = Color(0xFF8B5CF6)
val SonicGlassOverlay = Color(0x330F172A)
val SonicGlassLight = Color(0x22FFFFFF)

